export const config = {
  github: {
    token: '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',
    owner: 'AeroXDevs',
    repo: 'aerox-web',
    path: 'data/products.json'
  }
};
