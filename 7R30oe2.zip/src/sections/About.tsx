import { Shield, Target, Users, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const About = () => {
  return (
    <section 
      id="about" 
      className="py-24 bg-[#050505] text-[#00d2ff] font-mono relative overflow-hidden" 
    >
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#00d2ff]/30 to-transparent"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-block px-3 py-1 border border-[#00d2ff]/30 bg-[#00d2ff]/5 text-[10px] uppercase tracking-[0.4em] font-bold">
              Core_Identity
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black text-white leading-none">
              DECIPHERING <span className="text-[#00d2ff]">AEROX</span>
            </h2>
            
            <div className="space-y-6 text-white/60 leading-relaxed">
              <p className="text-lg">
                AeroX is an advanced neural network for developers. We eliminate the barriers between raw concepts and production-ready implementation.
              </p>
              
              <p className="border-l-2 border-[#00d2ff]/20 pl-6">
                We synthesize high-grade source code for web ecosystems, Discord automation, and distributed applications. From modular resources to full-stack solutions, our infrastructure supports every stage of the development lifecycle.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">
              {[
                { icon: Shield, title: "INTEGRITY", desc: "Hardened code standards" },
                { icon: Zap, title: "VELOCITY", desc: "Rapid deployment assets" },
                { icon: Users, title: "NETWORK", desc: "Peer-to-peer knowledge" },
                { icon: Target, title: "PRECISION", desc: "Optimized architecture" }
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex gap-4 p-4 border border-[#00d2ff]/5 bg-white/[0.02] hover:bg-white/[0.05] transition-colors group"
                >
                  <item.icon className="text-[#00d2ff]/40 group-hover:text-[#00d2ff] transition-colors" size={24} />
                  <div>
                    <div className="text-xs font-bold text-white uppercase tracking-wider mb-1">{item.title}</div>
                    <div className="text-[11px] opacity-60">{item.desc}</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative group w-full lg:sticky lg:top-32"
          >
            <div className="absolute -inset-4 bg-[#00d2ff]/5 blur-2xl rounded-full group-hover:bg-[#00d2ff]/10 transition-all duration-700"></div>
            <div className="relative border border-[#00d2ff]/20 rounded-xl overflow-hidden bg-black/40 backdrop-blur-sm p-5 md:p-8 min-h-[350px]">
              <div className="flex items-center justify-between mb-6 border-b border-[#00d2ff]/10 pb-4">
                <div className="text-[10px] text-white/30 uppercase tracking-widest">vision_protocol.sys</div>
                <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00d2ff]/30"></div>
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00d2ff]/30"></div>
                </div>
              </div>
              <div className="space-y-4 font-mono text-xs md:text-sm leading-relaxed opacity-80">
                <div className="flex gap-4">
                  <span className="text-[#00d2ff] shrink-0">01</span>
                  <span>Executing Mission_Module...</span>
                </div>
                <div className="flex gap-4">
                  <span className="text-[#00d2ff] shrink-0">02</span>
                  <span className="text-white">Our mission is to empower developers by providing accessible, well-documented source codes.</span>
                </div>
                <div className="flex gap-4">
                  <span className="text-[#00d2ff] shrink-0">03</span>
                  <span>Fostering a supportive community where knowledge is shared freely.</span>
                </div>
                <div className="flex gap-4">
                  <span className="text-[#00d2ff] shrink-0">04</span>
                  <span className="text-blue-400">Innovation_Status: THRIVING</span>
                </div>
                <div className="flex gap-4">
                  <span className="text-[#00d2ff] shrink-0">05</span>
                  <span>Global Synchronization: COMPLETE</span>
                </div>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default About;
