import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer 
      id="footer-section" 
      className="relative border-t border-[#00d2ff]/10 bg-[#050505] text-white"
    >
      <style>
        {`
          #footer-section {
            padding: 20px 50px 60px 50px;
            color: #FFF;
            position: relative;
          }

          .footer-content-wrapper {
            width: 100%;
          }
          
          @media screen and (min-width: 768px) {
             .footer-content-wrapper {
               width: 50%;
             }
          }

          @media screen and (max-width: 768px) {
            #footer-section {
              padding: 60px 6%;
            }
          }

          .admin-trigger {
            position: absolute;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            z-index: 10;
            cursor: pointer;
            opacity: 0.1;
            transition: opacity 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px dashed #00d2ff;
            border-radius: 4px;
            font-size: 8px;
            color: #00d2ff;
            text-align: center;
          }
          
          .admin-trigger:hover {
            opacity: 0.8;
          }
        `}
      </style>

      <div className="footer-content-wrapper">
        <span className="inline-block font-bold tracking-[0.3em] text-3xl bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent uppercase mb-8">AeroX</span>
        
        <div className="space-y-6 max-w-2xl mb-12">
          <p className="text-xl text-white/90 leading-relaxed font-medium tracking-tight">
            AeroX is pioneering the next generation of decentralized infrastructure. 
            Empowering architects and engineers to build a resilient, autonomous web.
          </p>
          <div className="h-px w-24 bg-[#00d2ff]/20"></div>
          <p className="text-[11px] text-white/30 uppercase tracking-[0.2em]">
            © 2026 INTERNAL_REGISTRY. All Rights Reserved.
          </p>
        </div>

        <div className="flex flex-wrap gap-8 items-center relative z-20">
          <Link to="/store" className="text-xs text-[#00d2ff] hover:text-white transition-colors uppercase tracking-widest font-bold" aria-label="Go to Store Access">
            [ Store_Access ]
          </Link>
        </div>
      </div>
      
      <Link to="/admin" aria-label="Admin Control Panel">
        <div className="admin-trigger" role="button">
          SYS_ADM<br/>CTRL
        </div>
      </Link>
    </footer>
  );
};

export default Footer;
