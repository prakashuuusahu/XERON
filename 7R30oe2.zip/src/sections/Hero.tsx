import { Terminal, Cpu, ChevronRight } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import { FloatingParticles } from '../components/visuals/CyberGrid';
import { ErrorBoundary } from 'react-error-boundary';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center bg-[#050505] text-white font-mono overflow-hidden selection:bg-[#00d2ff] selection:text-[#0a0a0a]">
      {/* Three.js Background */}
      <div className="absolute inset-0 z-0 opacity-40 pointer-events-none">
        <ErrorBoundary fallback={<div className="absolute inset-0 bg-black" />}>
          <Canvas camera={{ position: [0, 0, 10], fov: 75 }} gl={{ antialias: false, powerPreference: 'high-performance' }}>
            <FloatingParticles />
          </Canvas>
        </ErrorBoundary>
      </div>

      {/* Matrix-like background effect */}
      <div className="absolute inset-0 opacity-10 pointer-events-none z-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#00d2ff_0%,transparent_70%)] opacity-20"></div>
        <div className="h-full w-full bg-[linear-gradient(rgba(0,210,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,210,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>


      <div className="container mx-auto px-4 md:px-6 relative z-10 py-20 md:py-0">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="w-full max-w-2xl mx-auto border border-white/10 bg-[#0d1117]/80 backdrop-blur-xl rounded-lg overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5),0_0_20px_rgba(0,210,255,0.05)]"
        >
          {/* Terminal Header */}
          <div className="bg-[#161b22] px-4 py-3 flex items-center justify-between border-b border-white/5">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-[#ff5f56] shadow-inner"></div>
              <div className="w-3 h-3 rounded-full bg-[#ffbd2e] shadow-inner"></div>
              <div className="w-3 h-3 rounded-full bg-[#27c93f] shadow-inner"></div>
            </div>
            <div className="text-[10px] font-medium uppercase tracking-widest text-white/30 flex items-center gap-2">
              <Terminal size={12} className="text-[#00d2ff]" /> aerox_terminal
            </div>
            <div className="w-12"></div>
          </div>

          {/* Terminal Body */}
          <div className="p-6 md:p-8 space-y-6">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1 font-mono text-xs">
                <span className="text-[#00d2ff] font-bold">visitor@aerox</span>
                <span className="text-white/40">:</span>
                <span className="text-purple-400">~</span>
                <span className="text-white/60">$</span>
                <span className="text-white/80">npx aerox init <span className="animate-pulse">•</span></span>
              </div>
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1 font-mono text-[11px] text-white/60 pl-2 border-l border-[#00d2ff]/30">
                <span>Setting up development environment...</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-white leading-none mt-4">
                AeroX<span className="text-[#00d2ff]">_Dev</span>
              </h1>
            </div>

            <div className="space-y-3">
              <p className="text-sm md:text-lg text-white/70 max-w-2xl leading-relaxed font-light">
                A high-performance community for elite developers.
                Deploying <span className="text-white border-b border-[#00d2ff]/30">high-quality protocols</span> for the next generation of decentralized networks.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row flex-wrap gap-4 pt-6 border-t border-white/10">
              <a 
                href="https://discord.gg/8wfT8SfB5Z" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex items-center justify-center gap-3 bg-white text-black font-bold py-3 px-8 rounded-xl hover:bg-[#00d2ff] hover:text-white transition-all transform active:scale-95 shadow-xl text-xs flex-1"
              >
                JOIN COMMUNITY <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href="/codes" 
                className="group flex items-center justify-center gap-3 bg-white/5 text-white border border-white/10 font-bold py-3 px-8 rounded-xl hover:bg-white/10 hover:border-[#00d2ff]/30 transition-all text-xs flex-1"
              >
                VIEW SOURCE CODES <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
            
            <div className="pt-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-[10px] text-white/20 uppercase tracking-[0.3em]">
              <div className="flex items-center gap-2"><Cpu size={12} className="text-[#00d2ff]/40" /> System Status: Online</div>
              <div>// Port: 5000</div>
              <div>// Latency: 14ms</div>
            </div>
          </div>
        </motion.div>
      </div>
      
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  );
};

export default Hero;
