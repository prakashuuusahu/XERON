import DiscordIcon from '../components/icons/DiscordIcon';

const Navbar = () => {
  return (
    <header className="fixed top-0 left-0 w-full z-50 px-6 md:px-12">
      <nav className="py-5 flex justify-between items-center" aria-label="Main navigation">
        <a href="#hero" aria-label="AeroX Home">
          <span className="font-bold tracking-widest text-lg bg-gradient-to-r from-white to-cyan-400 bg-clip-text text-transparent uppercase">AeroX</span>
        </a>

        <div className="flex items-center gap-6">
          <a href="https://discord.gg/8wfT8SfB5Z" target="_blank" rel="noopener noreferrer" aria-label="Join our Discord community">
            <DiscordIcon className="w-7 h-7" />
          </a>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;