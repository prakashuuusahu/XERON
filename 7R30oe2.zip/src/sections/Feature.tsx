import { Package, Heart, ShoppingBag, Key, Youtube, Code, Terminal, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  { name: 'Basics', icon: Package, link: '/basics', color: 'text-blue-400', desc: 'Core Assets' },
  { name: 'Donate', icon: Heart, link: '/donate', color: 'text-rose-400', desc: 'Support Node' },
  { name: 'Codes', icon: Code, link: '/codes', color: 'text-emerald-500', desc: 'Source Library' },
  { name: 'Store', icon: ShoppingBag, link: '/store', color: 'text-[#00d2ff]', desc: 'Premium Hub' },
  { name: 'API Keys', icon: Key, link: '/api-keys', color: 'text-amber-400', desc: 'Access Vault' },
  { name: 'YouTube', icon: Youtube, link: '/youtube', color: 'text-red-500', desc: 'Media Stream' },
];

const Feature = () => {
  return (
    <section id="feature" className="py-24 bg-[#050505] text-white font-mono border-t border-[#00d2ff]/10 overflow-hidden">
      <div className="container mx-auto px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row justify-between items-end mb-24 gap-6"
        >
          <div className="space-y-2">
            <div className="text-[#00d2ff] text-xs font-bold uppercase tracking-[0.5em] mb-4 flex items-center gap-2">
              <Terminal size={14} /> System_Capabilities
            </div>
            <h2 className="text-4xl md:text-5xl font-black tracking-tighter uppercase leading-none text-white">
              Operational <span className="text-[#00d2ff]">Protocols</span>
            </h2>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 gap-2">
          {features.map((feature, i) => (
            <motion.a
              href={feature.link}
              key={feature.name}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative flex items-center justify-between p-6 transition-all duration-300 hover:bg-[#00d2ff]/5 border-l-4 border-transparent hover:border-[#00d2ff]"
            >
              <div className="flex items-center gap-8">
                <div className="text-sm font-bold text-[#00d2ff]/40 tabular-nums">
                  [{String(i + 1).padStart(2, '0')}]
                </div>
                
                <div className={`transition-transform duration-500 group-hover:scale-110 ${feature.color}`}>
                  <feature.icon size={24} />
                </div>

                <div className="space-y-0.5">
                  <h3 className="text-xl font-bold tracking-widest uppercase group-hover:text-white transition-colors">
                    {feature.name}
                  </h3>
                  <p className="text-[10px] text-white/30 uppercase tracking-[0.2em]">
                    {feature.desc}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="hidden md:flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-all duration-500 translate-x-4 group-hover:translate-x-0">
                  <div className="h-[1px] w-12 bg-white/10"></div>
                  <span className="text-[9px] text-white/40 font-bold tracking-[0.3em]">READY_TO_BOOT</span>
                </div>
                <ChevronRight className="text-white/20 group-hover:text-[#00d2ff] group-hover:opacity-100 transition-all" size={20} />
              </div>

              {/* Background text on hover */}
              <div className="absolute right-20 top-1/2 -translate-y-1/2 text-[4rem] font-black text-white/[0.02] pointer-events-none uppercase tracking-tighter opacity-0 group-hover:opacity-100 transition-opacity select-none">
                {feature.name}
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Feature;
