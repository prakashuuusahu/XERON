import { useEffect, useState } from 'react';

interface DiscordData {
  presence_count: number;
  members: Array<{
    username: string;
    avatar_url: string;
    status: string;
  }>;
  instant_invite: string;
}

const DiscordWidget = () => {
  const [data, setData] = useState<DiscordData | null>(null);
  const guildId = '1414217749038891102';

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`https://discord.com/api/guilds/${guildId}/widget.json`);
        const result = await response.json();
        setData(result);
      } catch (error) {
        console.error('Error fetching Discord widget data:', error);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, []);

  if (!data) return null;

  return (
    <section className="py-20 bg-black/50 backdrop-blur-sm border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="flex flex-col items-center justify-center gap-12">
          <div className="w-full text-center">
            <h2 className="font-kg-corner text-4xl sm:text-5xl text-white mb-6">
              Join Our Community
            </h2>
            <p className="font-ubuntu text-gray-300 text-lg mb-8 mx-auto max-w-lg">
              Connect with 1,800+ developers, share your projects, and get help in real-time. Our Discord is the heart of AeroX Development.
            </p>
          </div>

          <div className="w-full max-w-2xl bg-[#0d0d17] rounded-xl border border-green-500/30 overflow-hidden shadow-[0_0_30px_rgba(34,197,94,0.1)] font-mono">
            <div className="bg-[#1a1a2e] p-3 flex items-center justify-between border-b border-green-500/20">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#ff5f56]"></div>
                <div className="w-3 h-3 rounded-full bg-[#ffbd2e]"></div>
                <div className="w-3 h-3 rounded-full bg-[#27c93f]"></div>
                <span className="ml-4 text-green-500/70 text-xs tracking-tight">terminal — discord-status</span>
              </div>
              <div className="flex gap-4">
                <div className="w-2 h-2 border-r border-b border-green-500/30"></div>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-between mb-4 border-b border-green-500/10 pb-2">
                <span className="text-green-500 text-xs uppercase tracking-widest font-bold flex items-center gap-2">
                  <span className="text-green-500/50">&gt;</span> ONLINE_MEMBERS
                </span>
                <span className="text-green-400 text-xs flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                  SYSTEM_ACTIVE
                </span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {data.members.slice(0, 5).map((member, i) => (
                  <div key={i} className="flex items-center gap-3 bg-green-500/5 p-2 rounded border border-green-500/10 hover:bg-green-500/10 transition-colors group">
                    <div className="relative">
                      <img src={member.avatar_url} alt="" className="w-8 h-8 rounded-sm grayscale group-hover:grayscale-0 transition-all" />
                      <div className="absolute -bottom-1 -right-1 w-2.5 h-2.5 rounded-full bg-green-500 border-2 border-[#0d0d17]"></div>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-green-400 text-xs font-bold leading-none mb-1">{member.username}</span>
                      <span className="text-green-900 text-[10px] uppercase">Status: Online</span>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="pt-6 border-t border-green-500/10">
                <p className="text-green-700 text-xs mb-6 font-mono">
                  [REDACTED] ... and <span className="text-green-400 font-bold">{data.presence_count - 5}</span> additional nodes connected.
                </p>
                
                <div className="flex justify-center">
                  <a 
                    href={data.instant_invite}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group relative inline-flex items-center gap-3 bg-transparent border border-green-500 text-green-500 font-bold py-2 px-6 rounded hover:bg-green-500 hover:text-black transition-all text-xs uppercase tracking-widest"
                  >
                    <span className="absolute -left-1 -top-1 w-2 h-2 border-l border-t border-green-500"></span>
                    <span className="absolute -right-1 -bottom-1 w-2 h-2 border-r border-b border-green-500"></span>
                    Establish Connection
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiscordWidget;
