import { useState, useEffect } from 'react';
import { Code, ArrowLeft, Github, Youtube, FileCode, AlertCircle, Terminal } from 'lucide-react';
// @ts-ignore
import { config } from '../config';

interface VideoCode {
  id: string;
  videoTitle: string;
  videoId: string;
  thumbnail: string;
  codeLink: string;
  publishedAt: string;
}

const Codes = () => {
  const [codes, setCodes] = useState<VideoCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCodes = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const { owner, repo, token } = config.github;
        const response = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/contents/data/codes.json`,
          { 
            headers: {
              'Authorization': `token ${token}`,
              'Accept': 'application/vnd.github.v3.raw'
            },
            cache: 'no-store' 
          }
        );
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: Failed to fetch codes`);
        }
        
        const data = await response.json();
        setCodes(Array.isArray(data) ? data : []);
        setLoading(false);
      } catch (err) {
        console.error('Fetch error:', err);
        setError(err instanceof Error ? err.message : 'Failed to load source codes');
        setLoading(false);
      }
    };

    fetchCodes();
  }, []);

  return (
    <div className="min-h-screen bg-[#050505] text-white font-mono selection:bg-[#00d2ff] selection:text-[#0a0a0a]">
      {/* Matrix-like background effect */}
      <div className="fixed inset-0 opacity-10 pointer-events-none z-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#00d2ff_0%,transparent_70%)] opacity-20"></div>
        <div className="h-full w-full bg-[linear-gradient(rgba(0,210,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,210,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>

      {/* Header */}
      <nav className="fixed top-0 left-0 w-full z-50 px-6 py-4 flex justify-between items-center bg-[#0d1117]/80 backdrop-blur-xl border-b border-white/5">
        <a href="/" className="flex items-center gap-3 group transition-transform hover:scale-105">
          <img src="/hero/AeroX.png" alt="Logo" className="h-8 w-auto object-contain" />
          <span className="font-bold text-xl tracking-tighter">AEROX<span className="text-[#00d2ff]">_CODES</span></span>
        </a>
        <a
          href="/"
          className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-white border border-white/10 px-4 py-2 rounded-lg text-xs font-bold transition-all"
        >
          <ArrowLeft size={14} />
          BACK_TO_HOME
        </a>
      </nav>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-20 relative z-10">
        {/* Page Title */}
        <div className="max-w-4xl mx-auto mb-10 md:mb-16 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 text-[10px] text-[#00d2ff] uppercase tracking-[0.3em] mb-4">
            <Terminal size={12} /> system_repository_access
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-4 md:mb-6">
            Source_Codes<span className="text-[#00d2ff]">.list</span>
          </h1>
          <p className="text-white/60 text-xs sm:text-sm md:text-base max-w-2xl mx-auto md:mx-0 leading-relaxed">
            Access the complete infrastructure and codebase for all video tutorials. 
            Indexed and ready for deployment.
          </p>
        </div>

        {loading && (
          <div className="flex flex-col items-center justify-center py-20 md:py-32">
            <div className="w-10 h-10 md:w-12 md:h-12 border-2 border-[#00d2ff]/20 border-t-[#00d2ff] rounded-full animate-spin mb-4" />
            <p className="text-white/40 text-[10px] md:text-xs tracking-widest uppercase">Fetching_Data...</p>
          </div>
        )}

        {error && (
          <div className="max-w-2xl mx-auto px-4">
            <div className="bg-[#0d1117]/80 backdrop-blur-xl border border-red-500/20 rounded-lg p-6 md:p-8 text-center">
              <AlertCircle size={32} className="text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-bold mb-2">ACCESS_DENIED</h3>
              <p className="text-white/60 text-xs mb-6 font-mono break-all">{error}</p>
              <button 
                onClick={() => window.location.reload()}
                className="bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/30 py-2 px-6 rounded-lg text-xs font-bold transition-all w-full sm:w-auto"
              >
                RETRY_CONNECTION
              </button>
            </div>
          </div>
        )}

        {!loading && !error && (
          <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {codes.map((code) => (
              <div
                key={code.id}
                className="group bg-[#0d1117]/60 backdrop-blur-xl border border-white/5 hover:border-[#00d2ff]/30 rounded-lg overflow-hidden transition-all duration-300 flex flex-col"
              >
                {/* Thumbnail */}
                <div className="aspect-video w-full overflow-hidden relative">
                  {code.thumbnail ? (
                    <img 
                      src={code.thumbnail} 
                      alt={code.videoTitle}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full bg-white/5 flex items-center justify-center">
                      <FileCode size={40} className="text-white/10" />
                    </div>
                  )}
                  <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-[10px] text-white/60 border border-white/5">
                    {code.videoId}
                  </div>
                </div>

                <div className="p-4 md:p-5 flex flex-col flex-1">
                  <h3 className="font-bold text-sm md:text-base text-white/90 mb-4 md:mb-6 line-clamp-2 leading-tight group-hover:text-[#00d2ff] transition-colors">
                    {code.videoTitle}
                  </h3>
                  
                  <div className="mt-auto grid grid-cols-2 gap-2 md:gap-3">
                    <a
                      href={`https://youtube.com/watch?v=${code.videoId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 md:gap-2 bg-white/5 hover:bg-white/10 text-white/80 border border-white/10 py-2 md:py-2.5 rounded-lg text-[10px] md:text-[11px] font-bold transition-all uppercase tracking-wider"
                    >
                      <Youtube size={14} />
                      <span className="hidden xs:inline">Tutorial</span>
                      <span className="xs:hidden">Link</span>
                    </a>
                    <a
                      href={code.codeLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 md:gap-2 bg-[#00d2ff] hover:bg-[#00b8e6] text-black py-2 md:py-2.5 rounded-lg text-[10px] md:text-[11px] font-bold transition-all uppercase tracking-wider shadow-[0_0_15px_rgba(0,210,255,0.3)]"
                    >
                      <Github size={14} />
                      Code
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && !error && codes.length === 0 && (
          <div className="text-center py-20">
            <Code size={40} className="text-white/10 mx-auto mb-4" />
            <p className="text-white/40 text-xs tracking-widest uppercase">No_Repositories_Found</p>
          </div>
        )}
      </div>

      <footer className="py-12 border-t border-white/5 text-center text-white/20 text-[10px] uppercase tracking-[0.4em] font-medium">
        © 2026 AeroX_Protocol // Data_Stream_Active
      </footer>
    </div>
  );
};

export default Codes;
