import React from 'react';
import { Smartphone, Monitor, AlertCircle, FolderTree, Key, Settings, FileCode, Terminal as TerminalIcon, ChevronRight } from 'lucide-react';

interface TutorialCardProps {
  icon?: any;
  title: string;
  children: React.ReactNode;
}

const TutorialCard = ({ icon: Icon, title, children }: TutorialCardProps) => (
  <div className="bg-[#0a0a0f] border border-white/5 rounded-xl p-6 hover:border-[#00d2ff]/30 transition-all group flex flex-col h-full font-mono relative overflow-hidden">
    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00d2ff]/10 to-transparent"></div>
    <div className="flex items-center gap-3 mb-6">
      <div className="text-[#00d2ff]/50 group-hover:text-[#00d2ff] transition-colors">
        <Icon size={20} />
      </div>
      <h3 className="text-lg font-bold text-white tracking-tight uppercase">
        <span className="text-white/20 mr-2">#</span>
        {title}
      </h3>
    </div>
    <div className="space-y-4 text-white/50 text-sm leading-relaxed flex-grow">
      {children}
    </div>
    <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] text-white/20 uppercase tracking-widest">
      <span>Status: Decrypted</span>
      <span>AeroX_OS v2.0</span>
    </div>
  </div>
);

const BasicsPage = () => {
  const gradientStyle = `
    @keyframes scanline {
      0% { transform: translateY(-100%); }
      100% { transform: translateY(100%); }
    }
    @keyframes flicker {
      0% { opacity: 0.97; }
      5% { opacity: 0.95; }
      10% { opacity: 0.9; }
      15% { opacity: 0.95; }
      20% { opacity: 0.98; }
      100% { opacity: 1; }
    }
    .terminal-bg {
      background-color: #050505;
      background-image: 
        radial-gradient(circle at 50% 50%, #0a1a2a 0%, #050505 100%),
        linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%),
        linear-gradient(90deg, rgba(0, 210, 255, 0.03), rgba(0, 0, 0, 0), rgba(0, 210, 255, 0.03));
      background-size: 100% 100%, 100% 4px, 3px 100%;
    }
    .scanline {
      width: 100%;
      height: 100px;
      z-index: 10;
      background: linear-gradient(0deg, rgba(0, 210, 255, 0) 0%, rgba(0, 210, 255, 0.05) 50%, rgba(0, 210, 255, 0) 100%);
      opacity: 0.1;
      position: absolute;
      bottom: 100%;
      animation: scanline 8s linear infinite;
    }
    .flicker {
      animation: flicker 0.15s infinite;
    }
    kbd {
      background: #1a1a1a;
      border: 1px solid #333;
      border-radius: 3px;
      padding: 1px 5px;
      color: #00d2ff;
      font-size: 0.75rem;
    }
  `;

  return (
    <div className="min-h-screen terminal-bg text-white font-mono overflow-x-hidden relative">
      <style>{gradientStyle}</style>
      <div className="scanline pointer-events-none"></div>
      
      <nav className="fixed top-0 left-0 w-full z-50 px-6 py-4 flex justify-between items-center border-b border-white/5 bg-black/80 backdrop-blur-sm">
        <div className="flex items-center gap-4">
          <a href="/" className="hover:opacity-80 transition-opacity flex items-center gap-3">
            <img src="/hero/AeroX.png" alt="AeroX" className="w-8 h-8 object-contain shadow-[0_0_10px_rgba(0,210,255,0.3)] grayscale brightness-150" />
            <span className="text-white font-bold tracking-tighter text-xl">AEROX</span>
          </a>
          <div className="hidden sm:flex items-center gap-2 text-[10px] uppercase tracking-widest text-white/20">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00d2ff] animate-pulse"></span>
            System_Live
          </div>
        </div>
        <a href="/" className="group flex items-center gap-2 border border-white/10 px-4 py-1.5 rounded text-xs uppercase tracking-widest hover:bg-[#00d2ff] hover:text-black transition-all">
          <span className="text-white/30 group-hover:text-black">&lt;</span>
          Exit_Shell
        </a>
      </nav>

      <main className="container mx-auto px-6 pt-24 pb-20 max-w-6xl flicker">
        <div className="mb-16 border-l-2 border-[#00d2ff] pl-6 py-2">
          <div className="flex items-center gap-2 text-xs text-white/30 mb-2 uppercase tracking-[0.3em]">
            Directory: /home/aerox/docs
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4 tracking-tighter uppercase">
            Basics.sh <span className="animate-pulse">_</span>
          </h1>
          <p className="text-white/40 text-sm max-w-2xl">
            Initialization complete. Accessing core documentation for code manipulation and deployment protocols.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
          <TutorialCard icon={Key} title="Bot_Auth_Token">
            <p className="flex gap-2"><span className="text-white/20">1.</span> Navigate to Discord Dev Portal.</p>
            <p className="flex gap-2"><span className="text-white/20">2.</span> Initialize {"'"}New Application{"'"}.</p>
            <p className="flex gap-2"><span className="text-white/20">3.</span> Access {"'"}Bot{"'"} subsystem.</p>
            <p className="flex gap-2"><span className="text-white/20">4.</span> Trigger {"'"}Reset Token{"'"} to extract key.</p>
            <div className="bg-red-500/10 border border-red-500/20 p-3 mt-2 text-[10px] uppercase rounded-lg">
              <span className="text-red-500 font-bold mr-2">[CRITICAL]</span>
              Never expose token. Store in secured env vars only.
            </div>
          </TutorialCard>

          <TutorialCard icon={Settings} title="Gateway_Intents">
            <p className="text-white/20 italic text-xs mb-2">// Permission elevation required for member/message tracking</p>
            <ul className="space-y-1 text-xs">
              <li className="flex items-center gap-2"><ChevronRight size={12} className="text-[#00d2ff]" /> Toggle: Presence_Intent</li>
              <li className="flex items-center gap-2"><ChevronRight size={12} className="text-[#00d2ff]" /> Toggle: Server_Members_Intent</li>
              <li className="flex items-center gap-2"><ChevronRight size={12} className="text-[#00d2ff]" /> Toggle: Message_Content_Intent</li>
            </ul>
            <p className="mt-4 text-[10px] text-white/20 uppercase">Save required to commit changes to master.</p>
          </TutorialCard>

          <TutorialCard icon={FileCode} title="Project_Architecture">
            <div className="bg-black/40 p-4 border border-white/5 rounded-lg font-mono text-xs">
              <div className="text-[#00d2ff]">root/</div>
              <div className="pl-4 flex items-center gap-2"><span className="text-white/20">├──</span> 📁 node_modules/</div>
              <div className="pl-4 flex items-center gap-2"><span className="text-white/20">├──</span> 📁 commands/</div>
              <div className="pl-4 flex items-center gap-2"><span className="text-white/20">├──</span> 📄 index.js <span className="text-white/20">// Entry</span></div>
              <div className="pl-4 flex items-center gap-2"><span className="text-white/20">├──</span> 📄 config.json</div>
              <div className="pl-4 flex items-center gap-2"><span className="text-white/20">└──</span> 📄 package.json</div>
            </div>
          </TutorialCard>

          <TutorialCard icon={Monitor} title="Global_Replace_PC">
            <p>Execution Command:</p>
            <div className="bg-white/5 p-3 border border-white/10 rounded-lg">
              <code className="text-xs text-[#00d2ff]">CTRL + SHIFT + F</code>
            </div>
            <p className="text-xs mt-2">Reveal {"'"}Replace{"'"} vector via arrow toggle. Execute {"'"}Replace All{"'"} for recursive modification across entire workspace.</p>
          </TutorialCard>

          <TutorialCard icon={Smartphone} title="Sed_Modify_Mobile">
            <p className="text-xs mb-2">Targeted stream editor command for Termux environment:</p>
            <div className="bg-black/60 p-4 border border-white/10 rounded-lg text-[10px] text-[#00d2ff] overflow-x-auto whitespace-nowrap">
              grep -rl "target" . | xargs sed -i 's/target/new/g'
            </div>
            <p className="text-[10px] text-white/20 mt-2 uppercase">Warning: Operation is irreversible. Backup data recommended.</p>
          </TutorialCard>

          <TutorialCard icon={AlertCircle} title="Dependency_Fault">
            <p className="text-xs">Resolution steps for Pterodactyl {"'"}Module Not Found{"'"} errors:</p>
            <div className="space-y-2 mt-2">
              <div className="flex items-start gap-2 text-xs">
                <span className="text-[#00d2ff] mt-1">01</span>
                <span>Verify startup script points to valid entry file.</span>
              </div>
              <div className="flex items-start gap-2 text-xs">
                <span className="text-[#00d2ff] mt-1">02</span>
                <span>Run <code className="text-[#00d2ff]">npm install</code> to rebuild local modules.</span>
              </div>
            </div>
          </TutorialCard>
        </div>

        <div className="mt-16 bg-white/5 border border-white/10 rounded-2xl p-6 sm:p-8 text-center relative group overflow-hidden">
          <div className="absolute top-0 left-0 w-2 h-2 border-l border-t border-white/20"></div>
          <div className="absolute top-0 right-0 w-2 h-2 border-r border-t border-white/20"></div>
          <div className="absolute bottom-0 left-0 w-2 h-2 border-l border-b border-white/20"></div>
          <div className="absolute bottom-0 right-0 w-2 h-2 border-r border-b border-white/20"></div>
          
          <p className="text-xs sm:text-sm uppercase tracking-[0.2em] mb-6 text-white/40">Support_Uplink_Required?</p>
          <div className="flex justify-center">
            <a href="https://discord.gg/aerox" target="_blank" className="w-full sm:w-auto inline-block bg-white text-black px-6 sm:px-10 py-3 rounded-xl font-bold text-[10px] sm:text-xs uppercase tracking-widest hover:bg-[#00d2ff] transition-all transform hover:scale-105 active:scale-95 shadow-xl">
              Connect_To_Discord_Nodes
            </a>
          </div>
        </div>

        <footer className="mt-20 text-center text-white/10 text-[10px] uppercase tracking-[0.5em] pb-10">
          Terminal_Basics_v2.0 // End_Of_File
        </footer>
      </main>
    </div>
  );
};

export default BasicsPage;
