import { useState, useEffect } from 'react';
import { Copy, CheckCircle2, Key, ArrowLeft, Shield, Server, ShieldCheck, Activity } from 'lucide-react';
import { Canvas } from '@react-three/fiber';
import { FloatingParticles } from '../components/visuals/CyberGrid';
import { ErrorBoundary } from 'react-error-boundary';

interface ApiKey {
  id: string;
  name: string;
  key: string;
  status: 'online' | 'offline' | 'checking';
}

interface MongoCluster {
  region: string;
  location: string;
  url: string;
  status: 'online' | 'offline' | 'checking';
}

interface LavaLink {
  name: string;
  host: string;
  port: number;
  pass: string;
  secure: boolean;
  status: 'online' | 'offline' | 'checking';
}

const ApiKeysPage = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'mongo' | 'lava' | 'groq'>('mongo');
  
  const [mongoClusters, setMongoClusters] = useState<MongoCluster[]>([
    { region: '🇺🇸 US East', location: 'N. Virginia – us-east-1', url: 'mongodb+srv://AeroX:AeroX@aerox.xik7huh.mongodb.net/?retryWrites=true&w=majority&appName=AeroX', status: 'checking' },
    { region: '🇮🇳 Asia Pacific', location: 'Mumbai – ap-south-1', url: 'mongodb+srv://AeroX:AeroX@aerox.rv3nxmb.mongodb.net/?retryWrites=true&w=majority&appName=AeroX', status: 'checking' },
    { region: '🇩🇪 Europe', location: 'Frankfurt – eu-central-1', url: 'mongodb+srv://AeroX:AeroX@aerox.hae9rfp.mongodb.net/?retryWrites=true&w=majority&appName=AeroX', status: 'checking' },
    { region: '🇸🇬 Asia Pacific', location: 'Singapore – ap-southeast-1', url: 'mongodb+srv://AeroX:AeroX@aerox.cgfxn4x.mongodb.net/?retryWrites=true&w=majority&appName=AeroX', status: 'checking' },
    { region: '🇯🇵 Asia Pacific', location: 'Tokyo – ap-northeast-1', url: 'mongodb+srv://AeroX:AeroX@aerox.cgvmit4.mongodb.net/?retryWrites=true&w=majority&appName=AeroX', status: 'checking' },
    { region: '🇰🇷 Asia Pacific', location: 'Seoul – ap-northeast-2', url: 'mongodb+srv://AeroX:AeroX@aerox.9qfrqol.mongodb.net/?retryWrites=true&w=majority&appName=AeroX', status: 'checking' },
  ]);

  const [lavaLinks, setLavaLinks] = useState<LavaLink[]>([
    { name: 'v3 SSL', host: 'lava-v3.ajieblogs.eu.org', port: 443, pass: 'https://dsc.gg/ajidevserver', secure: true, status: 'checking' },
    { name: 'v3 NON-SSL', host: 'lava-v3.ajieblogs.eu.org', port: 80, pass: 'https://dsc.gg/ajidevserver', secure: false, status: 'checking' },
    { name: 'v4 SSL', host: 'lava-v4.ajieblogs.eu.org', port: 443, pass: 'https://dsc.gg/ajidevserver', secure: true, status: 'checking' },
    { name: 'v4 NON-SSL', host: 'lava-v4.ajieblogs.eu.org', port: 80, pass: 'https://dsc.gg/ajidevserver', secure: false, status: 'checking' },
    { name: 'LavaLink V4 - Nexus', host: 'nexus.voidhosting.vip', port: 6004, pass: 'cocaine', secure: false, status: 'online' },
    { name: 'LavaLink V4 - DanBot', host: 'pnode1.danbot.host', port: 1351, pass: 'cocaine', secure: false, status: 'online' },
  ]);

  const [groqKeys, setGroqKeys] = useState<ApiKey[]>([
    { id: 'key-1', name: 'API Key 1', key: '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', status: 'checking' },
    { id: 'key-2', name: 'API Key 2', key: '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', status: 'checking' },
    { id: 'key-3', name: 'API Key 3', key: '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', status: 'checking' },
    { id: 'key-4', name: 'API Key 4', key: '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', status: 'checking' },
    { id: 'key-5', name: 'API Key 5', key: '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', status: 'checking' },
  ]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const simulateStatus = () => {
    setMongoClusters(prev => prev.map(c => ({ ...c, status: Math.random() > 0.1 ? 'online' : 'offline' })));
    setLavaLinks(prev => prev.map(l => ({ ...l, status: Math.random() > 0.1 ? 'online' : 'offline' })));
    setGroqKeys(prev => prev.map(k => ({ ...k, status: Math.random() > 0.1 ? 'online' : 'offline' })));
  };

  useEffect(() => {
    simulateStatus();
    const interval = setInterval(simulateStatus, 300000); // 5 mins
    return () => clearInterval(interval);
  }, []);

  const pageStyle = `
    @keyframes orbit {
      from { transform: rotate(0deg) translateX(100px) rotate(0deg); }
      to { transform: rotate(360deg) translateX(100px) rotate(-360deg); }
    }
    .neon-card {
      background: rgba(13, 14, 24, 0.7);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(0, 210, 255, 0.1);
      box-shadow: 0 0 40px rgba(0, 0, 0, 0.5);
      transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .neon-card:hover {
      border-color: rgba(0, 210, 255, 0.5);
      box-shadow: 0 0 30px rgba(0, 210, 255, 0.15);
      transform: translateY(-5px);
    }
    .mesh-gradient {
      background: radial-gradient(at 0% 0%, rgba(0, 210, 255, 0.15) 0px, transparent 50%),
                  radial-gradient(at 100% 100%, rgba(0, 210, 255, 0.1) 0px, transparent 50%);
    }
    .status-pulse {
      animation: pulse-ring 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
    @keyframes pulse-ring {
      0% { transform: scale(0.8); opacity: 0.5; }
      50% { transform: scale(1.2); opacity: 0.3; }
      100% { transform: scale(0.8); opacity: 0.5; }
    }
    .hide-scrollbar::-webkit-scrollbar { display: none; }
    .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  `;

  return (
    <>
      <style>{pageStyle}</style>
      <div className="min-h-screen bg-[#080911] text-white font-mono selection:bg-[#00d2ff]/30 overflow-x-hidden relative">
        <div className="fixed inset-0 z-0 opacity-20">
          <ErrorBoundary fallback={<div />}>
            <Canvas camera={{ position: [0, 0, 10], fov: 75 }} gl={{ antialias: false, powerPreference: 'high-performance' }}>
              <FloatingParticles />
            </Canvas>
          </ErrorBoundary>
        </div>
        <div className="fixed inset-0 mesh-gradient pointer-events-none"></div>
        
        {/* Abstract Background Shapes */}
        <div className="fixed top-[-20%] left-[-10%] w-[600px] h-[600px] rounded-full bg-[#00d2ff]/10 blur-[150px] pointer-events-none"></div>
        <div className="fixed bottom-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-[#00d2ff]/5 blur-[150px] pointer-events-none"></div>

        {/* Navigation */}
        <nav className="fixed top-0 left-0 w-full z-50 px-4 md:px-8 py-4 flex justify-between items-center bg-[#080911]/60 backdrop-blur-2xl border-b border-white/5">
          <a href="/" className="flex items-center gap-2 group">
            <img src="/hero/AeroX.png" alt="AeroX" className="h-6 w-auto brightness-125" />
            <span className="font-bold tracking-widest text-lg bg-gradient-to-r from-white to-[#00d2ff] bg-clip-text text-transparent uppercase">AeroX</span>
          </a>
          <a href="/" className="group flex items-center gap-2 bg-white/5 hover:bg-white/10 px-4 py-2 rounded-xl text-[10px] font-black transition-all border border-white/5 uppercase tracking-[0.2em]">
            <ArrowLeft size={12} className="group-hover:-translate-x-1 transition-transform" />
            Return
          </a>
        </nav>

        <main className="container mx-auto px-4 md:px-6 pt-24 md:pt-32 pb-20 relative z-10 max-w-6xl">
          {/* Header */}
          <div className="mb-12 md:mb-16">
            <div className="flex items-center gap-2 text-[#00d2ff] text-[10px] font-bold uppercase tracking-[0.3em] mb-4">
              <ShieldCheck size={14} />
              Vault Systems Active
            </div>
            <h1 className="text-4xl md:text-7xl font-black mb-4 tracking-tight uppercase leading-none">
              Security <span className="text-[#00d2ff]">Hub</span>
            </h1>
            <p className="text-white/40 text-base md:text-lg max-w-xl font-medium">
              Real-time synchronization and monitoring for your distributed network credentials.
            </p>
          </div>

          {/* Tab Navigation - Scrollable on mobile */}
          <div className="flex overflow-x-auto hide-scrollbar gap-2 mb-8 bg-black/40 p-1.5 rounded-2xl border border-white/5 w-full md:w-fit backdrop-blur-md">
            {[
              { id: 'mongo', label: 'Clusters', color: '[#00d2ff]' },
              { id: 'lava', label: 'Nodes', color: '[#00d2ff]' },
              { id: 'groq', label: 'Groq API', color: '[#00d2ff]' }
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 md:flex-none whitespace-nowrap px-6 py-2.5 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${
                  activeTab === tab.id 
                    ? `bg-[#00d2ff] text-black shadow-lg` 
                    : 'text-white/30 hover:text-white/60'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content Area */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
            {activeTab === 'mongo' && mongoClusters.map((cluster, i) => (
              <div key={i} className="neon-card rounded-3xl p-6 md:p-8 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#00d2ff]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[#00d2ff]/10 transition-colors"></div>
                
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <div className="flex items-center gap-2 text-[#00d2ff] text-[10px] font-black uppercase tracking-widest mb-1">
                      <Server size={12} /> Regional Point
                    </div>
                    <h3 className="text-xl font-black tracking-tight">{cluster.region}</h3>
                    <p className="text-white/30 text-[10px] font-mono mt-1">{cluster.location}</p>
                  </div>
                  <div className={`w-2.5 h-2.5 rounded-full relative ${cluster.status === 'online' ? 'bg-emerald-400' : 'bg-rose-400'}`}>
                    <div className={`absolute inset-0 rounded-full status-pulse ${cluster.status === 'online' ? 'bg-emerald-400' : 'bg-rose-400'}`}></div>
                  </div>
                </div>
                
                <div className="bg-black/60 rounded-2xl p-4 mb-6 border border-white/5 group-hover:border-[#00d2ff]/20 transition-colors">
                  <code className="text-[10px] font-mono text-white/40 break-all leading-relaxed line-clamp-3 min-h-[4rem] block">
                    {cluster.url}
                  </code>
                </div>

                <button 
                  onClick={() => copyToClipboard(cluster.url, `mongo-${i}`)}
                  className="w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 bg-white/5 hover:bg-[#00d2ff] hover:text-black transition-all border border-white/5 hover:border-[#00d2ff]/40"
                >
                  {copiedId === `mongo-${i}` ? <><CheckCircle2 size={14} className="text-black" /> Copied</> : <><Copy size={14} /> Copy Cluster URI</>}
                </button>
              </div>
            ))}

            {activeTab === 'lava' && lavaLinks.map((link, i) => (
              <div key={i} className="neon-card rounded-3xl p-6 md:p-8 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#00d2ff]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[#00d2ff]/10 transition-colors"></div>
                
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-black tracking-tight uppercase">{link.name}</h3>
                  <div className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border ${link.status === 'online' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border-rose-500/20'}`}>
                    {link.status}
                  </div>
                </div>
                
                <div className="space-y-4 mb-8">
                  {[
                    { label: 'Host', value: link.host },
                    { label: 'Port', value: link.port },
                    { label: 'Password', value: link.pass, secret: false }
                  ].map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center">
                      <span className="text-[10px] text-white/20 uppercase tracking-widest font-bold">{item.label}</span>
                      <span className={`text-[11px] font-mono ${item.label === 'Password' ? 'text-[#00d2ff]' : 'text-white/60'}`}>
                        {item.value}
                      </span>
                    </div>
                  ))}
                </div>

                <button 
                  onClick={() => copyToClipboard(`${link.host}:${link.port}`, `lava-${i}`)}
                  className="w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 bg-white/5 hover:bg-[#00d2ff] hover:text-black transition-all border border-white/5 hover:border-[#00d2ff]/40"
                >
                  {copiedId === `lava-${i}` ? <><CheckCircle2 size={14} className="text-black" /> Copied</> : <><Copy size={14} /> Copy Endpoint</>}
                </button>
              </div>
            ))}

            {activeTab === 'groq' && groqKeys.map((key, i) => (
              <div key={i} className="neon-card rounded-3xl p-6 md:p-8 md:col-span-2 lg:col-span-1 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#00d2ff]/5 blur-3xl -mr-16 -mt-16 group-hover:bg-[#00d2ff]/10 transition-colors"></div>
                
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl font-black tracking-tight uppercase">{key.name}</h3>
                  </div>
                  <div className={`w-2.5 h-2.5 rounded-full relative ${key.status === 'online' ? 'bg-emerald-400' : 'bg-rose-400'}`}>
                    <div className={`absolute inset-0 rounded-full status-pulse ${key.status === 'online' ? 'bg-emerald-400' : 'bg-rose-400'}`}></div>
                  </div>
                </div>

                <div className="bg-black/60 rounded-2xl p-5 mb-8 border border-white/5 font-mono text-[11px] text-white/40 break-all leading-relaxed relative overflow-hidden">
                  <Shield size={60} className="absolute -right-4 -bottom-4 text-[#00d2ff]/5" />
                  {key.key}
                </div>

                <button 
                  onClick={() => copyToClipboard(key.key, key.id)}
                  className="w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 bg-white/5 hover:bg-[#00d2ff] hover:text-black transition-all border border-white/5 hover:border-[#00d2ff]/40"
                >
                  {copiedId === key.id ? <><CheckCircle2 size={14} className="text-black" /> Decrypted</> : <><Key size={14} /> Access Key</>}
                </button>
              </div>
            ))}
          </div>
        </main>

        <footer className="py-12 border-t border-white/5 bg-black/20 backdrop-blur-md relative z-10 text-center">
          <div className="text-white/20 text-[10px] font-black uppercase tracking-[0.4em] mb-6 px-4">
            AeroX Security Protocol — Verified End-to-End
          </div>
          <div className="flex justify-center gap-6 text-white/10">
            <Shield size={18} className="hover:text-[#00d2ff]/50 transition-colors" />
            <Activity size={18} className="hover:text-emerald-500/50 transition-colors" />
            <Key size={18} className="hover:text-[#00d2ff]/50 transition-colors" />
          </div>
        </footer>
      </div>
    </>
  );
};

export default ApiKeysPage;
