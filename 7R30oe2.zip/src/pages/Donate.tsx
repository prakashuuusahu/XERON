import { useState } from 'react';
import { Copy, CheckCircle2, Wallet, QrCode, Terminal, ChevronRight, Shield, CreditCard } from 'lucide-react';

const Donate = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  const ltcAddress = 'ltc1qkp7hhsdwfu4p2fm52p55x589dr5g5qc3s76xmj';
  const usdtAddress = '0x9A0c51fAB6d17bfbA76aC219231b8A01B895f3B3';
  const paypalId = '@Ishika870';

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-mono selection:bg-[#00d2ff]/30 overflow-x-hidden">
      {/* Matrix Background Effect */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#00d2ff_0%,transparent_70%)] opacity-20"></div>
        <div className="h-full w-full bg-[linear-gradient(rgba(0,210,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,210,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 w-full z-50 px-4 md:px-8 py-4 flex justify-between items-center bg-[#0a0a0a]/80 backdrop-blur-md border-b border-white/5">
        <a href="/" className="group flex items-center gap-2">
          <span className="font-bold tracking-widest text-lg bg-gradient-to-r from-white to-[#00d2ff] bg-clip-text text-transparent uppercase">AeroX</span>
        </a>
        <a
          href="/"
          className="group flex items-center gap-2 bg-white/5 hover:bg-white/10 px-4 py-2 rounded border border-white/10 text-[10px] font-bold uppercase tracking-widest transition-all"
        >
          <ChevronRight size={14} className="rotate-180 group-hover:-translate-x-1 transition-transform" />
          EXIT_TO_ROOT
        </a>
      </nav>

      <main className="container mx-auto px-4 pt-32 pb-20 relative z-10 max-w-6xl">
        {/* Header */}
        <div className="mb-16 space-y-4">
          <div className="flex items-center gap-2 text-[#00d2ff]/40 text-xs uppercase tracking-[0.4em]">
            <Terminal size={14} /> contribution_protocol.sh
          </div>
          <h1 className="text-4xl md:text-7xl font-black tracking-tighter uppercase leading-none text-white">
            Support <span className="text-[#00d2ff]">Network</span>
          </h1>
          <p className="text-white/60 text-base md:text-lg max-w-2xl leading-relaxed border-l-2 border-[#00d2ff]/30 pl-6">
            Help us maintain high-performance infrastructure and keep our elite source codes decentralized and accessible to all developers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* UPI Donation - Scanner Theme */}
          <div className="relative group p-8 border border-white/10 bg-black/60 backdrop-blur-sm overflow-hidden rounded-2xl">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00d2ff] to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-pulse transition-opacity"></div>
            
            <div className="flex justify-between items-start mb-10">
              <div className="space-y-1">
                <div className="text-[10px] text-white/30 uppercase tracking-widest">Protocol 01</div>
                <h3 className="text-2xl font-black tracking-tight text-white uppercase">UPI_SCANNER</h3>
              </div>
              <QrCode size={24} className="text-[#00d2ff]" />
            </div>

            <div className="relative mx-auto max-w-[240px] p-2 border-2 border-dashed border-white/10 rounded-lg group-hover:border-[#00d2ff]/60 transition-colors">
              <div className="absolute inset-0 bg-[#00d2ff]/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <img src="/donate/upi-qr.png" alt="UPI QR Code" className="w-full h-auto grayscale brightness-90 group-hover:grayscale-0 transition-all" />
              {/* Scanline Effect */}
              <div className="absolute top-0 left-0 w-full h-0.5 bg-[#00d2ff] shadow-[0_0_10px_#00d2ff] opacity-0 group-hover:opacity-100 group-hover:animate-[scanline_3s_linear_infinite]"></div>
            </div>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              {['GPAY', 'PHONEPE', 'PAYTM'].map(tag => (
                <span key={tag} className="text-[9px] font-bold px-2 py-1 bg-white/5 border border-white/10 text-white/40">{tag}</span>
              ))}
            </div>
          </div>

          {/* PayPal Donation */}
          <div className="relative group p-8 border border-white/10 bg-black/60 backdrop-blur-sm rounded-2xl flex flex-col">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00d2ff] to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-pulse transition-opacity"></div>
            
            <div className="flex justify-between items-start mb-10">
              <div className="space-y-1">
                <div className="text-[10px] text-white/30 uppercase tracking-widest">Protocol 02</div>
                <h3 className="text-2xl font-black tracking-tight text-white uppercase">PAYPAL_RELAY</h3>
              </div>
              <CreditCard size={24} className="text-[#00d2ff]" />
            </div>

            <div className="flex-1 flex flex-col justify-center space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] text-white/30 uppercase tracking-[0.3em] font-bold block text-center">
                  MERCHANT_ID
                </label>
                <div className="bg-white/5 border border-white/10 p-4 break-all font-mono text-lg text-[#00d2ff] relative group/addr overflow-hidden rounded-lg text-center">
                  <span className="relative z-10">{paypalId}</span>
                </div>
              </div>

              <a
                href={`https://www.paypal.com/paypalme/${paypalId.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-4 px-2 bg-[#00d2ff] text-black font-black uppercase tracking-tight transition-all hover:bg-[#00b8e6] active:scale-95 rounded-xl shadow-xl text-center text-[10px] xs:text-xs sm:text-sm md:text-base whitespace-nowrap"
              >
                EXECUTE_PAYPAL_TRANSFER
              </a>
            </div>
          </div>

          {/* Crypto Donation - LTC */}
          <div className="relative group p-8 border border-white/10 bg-black/60 backdrop-blur-sm rounded-2xl">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00d2ff] to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-pulse transition-opacity"></div>
            
            <div className="flex justify-between items-start mb-10">
              <div className="space-y-1">
                <div className="text-[10px] text-white/30 uppercase tracking-widest">Protocol 03</div>
                <h3 className="text-2xl font-black tracking-tight text-white uppercase">LTC_VAULT</h3>
              </div>
              <Wallet size={24} className="text-[#00d2ff]" />
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] text-white/30 uppercase tracking-[0.3em] font-bold block text-center">
                  NETWORK_ADDRESS
                </label>
                <div className="bg-white/5 border border-white/10 p-4 break-all font-mono text-sm text-[#00d2ff] relative group/addr overflow-hidden rounded-lg text-center">
                  <div className="absolute inset-0 bg-[#00d2ff]/5 translate-x-[-100%] group-hover/addr:translate-x-0 transition-transform duration-500"></div>
                  <span className="relative z-10">{ltcAddress}</span>
                </div>
              </div>

              <button
                onClick={() => copyToClipboard(ltcAddress, 'ltc')}
                className={`w-full flex items-center justify-center gap-2 py-4 px-2 font-black uppercase tracking-tight transition-all relative overflow-hidden border rounded-xl text-center text-[10px] xs:text-xs sm:text-sm md:text-base whitespace-nowrap ${
                  copiedId === 'ltc'
                    ? 'bg-[#00d2ff] text-black border-[#00d2ff]'
                    : 'bg-transparent text-white/60 border-white/10 hover:bg-white/5'
                }`}
              >
                {copiedId === 'ltc' ? <><CheckCircle2 size={16} /> ADDRESS_COPIED</> : <><Copy size={16} /> INITIALIZE_COPY</>}
              </button>
            </div>
          </div>

          {/* Crypto Donation - USDT Polygon */}
          <div className="relative group p-8 border border-white/10 bg-black/60 backdrop-blur-sm rounded-2xl">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#00d2ff] to-transparent opacity-0 group-hover:opacity-100 group-hover:animate-pulse transition-opacity"></div>
            
            <div className="flex justify-between items-start mb-10">
              <div className="space-y-1">
                <div className="text-[10px] text-white/30 uppercase tracking-widest">Protocol 04</div>
                <h3 className="text-2xl font-black tracking-tight text-white uppercase">USDT_POLYGON</h3>
              </div>
              <Wallet size={24} className="text-[#00d2ff]" />
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] text-white/30 uppercase tracking-[0.3em] font-bold block text-center">
                  POLYGON_NETWORK_ADDRESS
                </label>
                <div className="bg-white/5 border border-white/10 p-4 break-all font-mono text-sm text-[#00d2ff] relative group/addr overflow-hidden rounded-lg text-center">
                  <div className="absolute inset-0 bg-[#00d2ff]/5 translate-x-[-100%] group-hover/addr:translate-x-0 transition-transform duration-500"></div>
                  <span className="relative z-10">{usdtAddress}</span>
                </div>
              </div>

              <button
                onClick={() => copyToClipboard(usdtAddress, 'usdt')}
                className={`w-full flex items-center justify-center gap-2 py-4 px-2 font-black uppercase tracking-tight transition-all relative overflow-hidden border rounded-xl text-center text-[10px] xs:text-xs sm:text-sm md:text-base whitespace-nowrap ${
                  copiedId === 'usdt'
                    ? 'bg-[#00d2ff] text-black border-[#00d2ff]'
                    : 'bg-transparent text-white/60 border-white/10 hover:bg-white/5'
                }`}
              >
                {copiedId === 'usdt' ? <><CheckCircle2 size={16} /> ADDRESS_COPIED</> : <><Copy size={16} /> INITIALIZE_COPY</>}
              </button>
              
              <div className="p-3 bg-white/5 border border-white/10 text-[9px] text-white/40 uppercase tracking-widest flex items-center gap-3 rounded-lg">
                <Shield size={14} className="shrink-0" />
                Warning: Deploy only USDT (POLYGON) to this endpoint.
              </div>
            </div>
          </div>
        </div>

        <div className="relative p-6 md:p-10 border border-white/5 bg-black/40 backdrop-blur-lg text-center overflow-hidden group w-full rounded-2xl">
          <div className="absolute inset-0 bg-[#00d2ff]/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <h3 className="text-xl md:text-3xl font-black mb-4 text-white uppercase tracking-tighter break-words">System_Acknowledgement</h3>
          <p className="text-white/40 text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
            Your contributions directly fuel the development of high-performance tools and maintenance of our decentralized nodes.
          </p>
          <div className="flex flex-wrap justify-center gap-x-8 gap-y-4 text-[10px] text-white/20 uppercase tracking-[0.3em] font-bold">
            <span className="flex items-center gap-2">[ Rapid_Updates ]</span>
            <span className="flex items-center gap-2">[ Advanced_Tooling ]</span>
            <span className="flex items-center gap-2">[ Global_Access ]</span>
          </div>
        </div>
      </main>

      <style>{`
        @keyframes scanline {
          0% { transform: translateY(0); }
          100% { transform: translateY(240px); }
        }
      `}</style>
    </div>
  );
};

export default Donate;
