import { useState, useEffect } from 'react';
import { Play, Youtube as YoutubeIcon, ArrowLeft, ExternalLink, Calendar, Info } from 'lucide-react';

interface Video {
  id: string;
  title: string;
  thumbnail: string;
  publishedAt: string;
  description: string;
}

const YouTube = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const pageStyle = `
    :root {
      --cream: #f4ede3;
      --maroon: #90353d;
      --muted: rgba(0,0,0,0.65);
      --card-shadow: 0 10px 30px rgba(144,53,61,0.06);
    }

    @keyframes floating {
      0% { transform: translateY(0px); }
      50% { transform: translateY(-6px); }
      100% { transform: translateY(0px); }
    }
    .floating { animation: floating 6s ease-in-out infinite; }

    .glass-card {
      background: rgba(244, 237, 227, 0.7);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(144, 53, 61, 0.1);
      transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      box-shadow: var(--card-shadow);
    }

    .glass-card:hover {
      background: rgba(244, 237, 227, 0.9);
      border-color: rgba(144, 53, 61, 0.3);
      box-shadow: 0 15px 40px rgba(144, 53, 61, 0.12);
      transform: translateY(-4px);
    }

    @keyframes spin-slow {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    .animate-spin-slow {
      animation: spin-slow 3s linear infinite;
    }
  `;

  useEffect(() => {
    const fetchVideos = async () => {
      const API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;
      const CHANNEL_HANDLE = '@aerox-devs';
      
      try {
        const channelResponse = await fetch(
          `https://www.googleapis.com/youtube/v3/channels?part=contentDetails,snippet&forHandle=${CHANNEL_HANDLE}&key=${API_KEY}`
        );
        
        if (!channelResponse.ok) throw new Error('Failed to fetch channel data');
        const channelData = await channelResponse.json();
        if (!channelData.items || channelData.items.length === 0) throw new Error('Channel not found');
        
        const uploadsPlaylistId = channelData.items[0].contentDetails.relatedPlaylists.uploads;
        
        const videosResponse = await fetch(
          `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${uploadsPlaylistId}&maxResults=12&key=${API_KEY}`
        );
        
        if (!videosResponse.ok) throw new Error('Failed to fetch videos');
        const videosData = await videosResponse.json();
        
        const fetchedVideos: Video[] = videosData.items.map((item: any) => ({
          id: item.snippet.resourceId.videoId,
          title: item.snippet.title,
          thumbnail: item.snippet.thumbnails.high.url,
          publishedAt: item.snippet.publishedAt,
          description: item.snippet.description,
        }));
        
        setVideos(fetchedVideos);
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
        setLoading(false);
      }
    };

    fetchVideos();
  }, []);

  return (
    <>
      <style>{pageStyle}</style>
      <div className="min-h-screen bg-gradient-to-br from-[#f4ede3] to-[#efe7e5] text-[#2a2a2a]">
        
        {/* Header */}
        <nav className="fixed top-0 left-0 w-full z-50 px-6 py-6 flex justify-between items-center bg-white/80 backdrop-blur-md border-b border-[#90353d]/10">
          <a href="/" className="flex items-center gap-3 group transition-transform hover:scale-105">
            <img src="/hero/AeroX.png" alt="Logo" className="h-10 w-auto object-contain" />
            <span className="font-bold text-2xl text-[#90353d]">AEROX</span>
          </a>
          <a
            href="/"
            className="flex items-center gap-2 bg-[#90353d] hover:bg-[#7a2b30] text-white px-5 py-2.5 rounded-lg text-sm font-bold transition-all"
          >
            <ArrowLeft size={16} />
            Back
          </a>
        </nav>

        <div className="container mx-auto px-6 pt-40 pb-20 relative">
          {/* Decorative Background */}
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="absolute top-20 right-20 w-72 h-72 bg-[#90353d] rounded-full blur-3xl"></div>
            <div className="absolute bottom-20 left-20 w-72 h-72 bg-[#90353d] rounded-full blur-3xl"></div>
          </div>

          {/* Hero Section */}
          <div className="max-w-4xl mx-auto text-center mb-24 relative z-10">
            <div className="inline-flex items-center gap-2 bg-[#90353d]/10 border border-[#90353d]/20 px-4 py-1.5 rounded-full text-[#90353d] text-xs font-bold uppercase tracking-widest mb-8 floating">
              <YoutubeIcon size={14} />
              Official Channel
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-8 tracking-tight text-[#90353d]">
              Creative <span className="text-[#90353d]/80">Content</span> Hub
            </h1>
            <p className="text-gray-600 text-lg md:text-xl mb-12 leading-relaxed">
              Explore professional tutorials, project showcases, and development deep-dives from the AeroX team.
            </p>

            <div className="flex flex-wrap gap-4 justify-center items-center">
              <a 
                href="https://youtube.com/@aerox-devs?sub_confirmation=1" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group bg-[#90353d] hover:bg-[#7a2b30] text-white px-8 py-4 rounded-lg transition-all duration-300 font-bold flex items-center gap-3 shadow-lg"
              >
                <YoutubeIcon className="group-hover:rotate-12 transition-transform" />
                Subscribe Now
              </a>
              <a 
                href="https://youtube.com/@aerox-devs/videos" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-white hover:bg-gray-100 border border-[#90353d]/20 text-[#90353d] px-8 py-4 rounded-lg transition-all font-bold"
              >
                Browse Archive
              </a>
            </div>
          </div>

          {loading && (
            <div className="flex flex-col items-center justify-center py-40 relative z-10">
              <div className="relative w-16 h-16">
                <div className="absolute inset-0 rounded-full border-4 border-[#90353d]/20 border-t-[#90353d] animate-spin"></div>
              </div>
              <p className="mt-8 text-gray-600 font-medium tracking-widest uppercase text-xs">Loading videos...</p>
            </div>
          )}

          {error && (
            <div className="max-w-xl mx-auto glass-card rounded-2xl p-10 text-center relative z-10">
              <div className="w-16 h-16 bg-[#90353d]/10 rounded-lg flex items-center justify-center mx-auto mb-6 text-[#90353d]">
                <Info size={32} />
              </div>
              <h3 className="text-xl font-bold mb-3 text-[#90353d]">Unable to Load Videos</h3>
              <p className="text-gray-600 text-sm mb-8 leading-relaxed">{error}</p>
              <button 
                onClick={() => window.location.reload()}
                className="w-full bg-[#90353d] hover:bg-[#7a2b30] text-white py-3 rounded-lg font-bold transition-all"
              >
                Retry
              </button>
            </div>
          )}

          {!loading && !error && videos.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative z-10">
              {videos.map((video) => (
                <a
                  key={video.id}
                  href={`https://www.youtube.com/watch?v=${video.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group glass-card rounded-2xl overflow-hidden"
                >
                  <div className="relative aspect-video overflow-hidden">
                    <img 
                      src={video.thumbnail} 
                      alt={video.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#2a2a2a] via-transparent to-transparent opacity-40"></div>
                    
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-14 h-14 bg-[#90353d] rounded-full flex items-center justify-center transform scale-0 group-hover:scale-100 transition-all duration-500">
                        <Play size={24} fill="white" className="ml-1 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="font-bold text-lg mb-4 line-clamp-2 leading-tight text-[#90353d] group-hover:text-[#7a2b30] transition-colors">
                      {video.title}
                    </h3>
                    
                    <div className="flex flex-col gap-4 mt-auto">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-gray-600 text-xs font-medium uppercase">
                          <Calendar size={14} className="text-[#90353d]/60" />
                          {new Date(video.publishedAt).toLocaleDateString('en-US', { 
                            month: 'short', 
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </div>
                        <div className="p-2 rounded-lg bg-[#90353d]/10 text-[#90353d] group-hover:bg-[#90353d] group-hover:text-white transition-all">
                          <ExternalLink size={14} />
                        </div>
                      </div>
                      <div className="text-gray-600 text-[10px] uppercase tracking-[0.2em] border-t border-[#90353d]/10 pt-4 font-mono group-hover:text-[#90353d]/60 transition-colors">
                        Stream_ID: {video.id}
                      </div>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          )}
        </div>

        <footer className="py-10 border-t border-[#90353d]/10 text-center text-gray-600 text-xs uppercase tracking-wider">
          © 2026 AeroX Development
        </footer>
      </div>
    </>
  );
};

export default YouTube;
