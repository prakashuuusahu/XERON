import { useState, useEffect } from 'react';
import { ArrowLeft, Trash2, Plus, LogOut, LayoutDashboard, ShoppingBag, Code, Settings, Activity, ShieldCheck, Database, Menu, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { productService } from '../lib/productService';

const AdminPanel = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState('');
  const [products, setProducts] = useState<any[]>([]);
  const [codes, setCodes] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'products' | 'codes' | 'settings'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  useEffect(() => {
    if (isLoggedIn) {
      fetchProducts();
      fetchCodes();
    }
  }, [isLoggedIn]);

  const fetchProducts = async () => {
    try {
      const data = await productService.getAllProducts();
      setProducts(data || []);
    } catch (error) {
      console.error('Failed to fetch products:', error);
    }
  };

  const fetchCodes = async () => {
    try {
      const data = await productService.getAllCodes();
      setCodes(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Failed to fetch codes:', error);
    }
  };

  const fetchYoutubeVideos = async () => {
    const apiKey = import.meta.env.VITE_YOUTUBE_API_KEY;
    if (!apiKey) {
      alert('YouTube API key not configured');
      return;
    }

    setLoadingVideos(true);
    try {
      const channelResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=contentDetails,snippet&forHandle=@aerox-devs&key=${apiKey}`
      );
      
      if (!channelResponse.ok) throw new Error('Failed to fetch channel');
      const channelData = await channelResponse.json();
      if (!channelData.items?.length) throw new Error('Channel not found');
      
      const uploadsPlaylistId = channelData.items[0].contentDetails.relatedPlaylists.uploads;
      
      const videosResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${uploadsPlaylistId}&maxResults=50&key=${apiKey}`
      );
      
      if (!videosResponse.ok) throw new Error('Failed to fetch videos');
      const videosData = await videosResponse.json();
      
      const videos = videosData.items.map((item: any) => ({
        videoId: item.snippet.resourceId.videoId,
        videoTitle: item.snippet.title,
        thumbnail: item.snippet.thumbnails.high.url,
        publishedAt: item.snippet.publishedAt,
      }));
      
      setYoutubeVideos(videos);
      setLoadingVideos(false);
    } catch (error) {
      console.error('Failed to fetch YouTube videos:', error);
      alert('Failed to fetch YouTube videos');
      setLoadingVideos(false);
    }
  };

  const [imageUrl, setImageUrl] = useState('');
  const [newProduct, setNewProduct] = useState({ title: '', description: '', price: '', images: [] as string[] });
  
  const [editingCodeId, setEditingCodeId] = useState<string | null>(null);
  const [newCode, setNewCode] = useState({ videoTitle: '', videoId: '', thumbnail: '', codeLink: '', publishedAt: '' });
  const [youtubeVideos, setYoutubeVideos] = useState<any[]>([]);
  const [loadingVideos, setLoadingVideos] = useState(false);
  const [videoSearchQuery, setVideoSearchQuery] = useState('');
  
  const filteredVideos = youtubeVideos.filter(v => 
    v.videoTitle.toLowerCase().includes(videoSearchQuery.toLowerCase()) ||
    v.videoId.toLowerCase().includes(videoSearchQuery.toLowerCase())
  );

  const [editingId, setEditingId] = useState<string | null>(null);
  const navigate = useNavigate();

  const ADMIN_PASSWORD = "nicetrydiddy";

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsLoggedIn(true);
    } else {
      alert("Invalid Password");
    }
  };

  const handleAddImageUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (imageUrl.trim()) {
      setNewProduct(prev => ({ 
        ...prev, 
        images: [...prev.images, imageUrl.trim()] 
      }));
      setImageUrl('');
    }
  };

  const addProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const productToSave = { 
        ...newProduct, 
        id: editingId || Date.now().toString(),
        images: Array.isArray(newProduct.images) ? [...newProduct.images] : []
      };
      
      await productService.saveProduct(productToSave);
      
      setTimeout(async () => {
        await fetchProducts();
        setNewProduct({ title: '', description: '', price: '', images: [] });
        setImageUrl('');
        setEditingId(null);
      }, 1000);
      
    } catch (error: any) {
      console.error('Failed to save product:', error);
      alert(`Failed to save product: ${error.message}`);
    }
  };

  const startEdit = (product: any) => {
    setEditingId(product.id);
    setNewProduct({ 
      title: product.title, 
      description: product.description, 
      price: product.price, 
      images: product.images || (product.image ? [product.image] : [])
    });
    setActiveTab('products');
  };

  const removeProduct = async (id: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;
    try {
      await productService.deleteProduct(id);
      await fetchProducts();
    } catch (error: any) {
      console.error('Failed to delete product:', error);
      alert(`Failed to delete product: ${error.message}`);
    }
  };

  const addCode = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const codeToSave = { 
        ...newCode, 
        id: editingCodeId || Date.now().toString(),
      };
      
      const updatedCodes = editingCodeId 
        ? codes.map(c => c.id === editingCodeId ? codeToSave : c)
        : [...codes, codeToSave];
      
      await productService.saveData('codes.json', updatedCodes);
      await fetchCodes();
      setNewCode({ videoTitle: '', videoId: '', thumbnail: '', codeLink: '', publishedAt: '' });
      setEditingCodeId(null);
    } catch (error: any) {
      console.error('Failed to save code:', error);
      alert(`Failed to save code: ${error.message}`);
    }
  };

  const startEditCode = (code: any) => {
    setEditingCodeId(code.id);
    setNewCode({
      videoTitle: code.videoTitle,
      videoId: code.videoId,
      thumbnail: code.thumbnail,
      codeLink: code.codeLink,
      publishedAt: code.publishedAt
    });
    setActiveTab('codes');
  };

  const removeCode = async (id: string) => {
    if (!confirm('Are you sure you want to delete this code?')) return;
    try {
      const updatedCodes = codes.filter(c => c.id !== id);
      await productService.saveData('codes.json', updatedCodes);
      await fetchCodes();
    } catch (error: any) {
      console.error('Failed to delete code:', error);
      alert(`Failed to delete code: ${error.message}`);
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4 font-mono selection:bg-[#00ff41] selection:text-[#0a0a0a]">
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <div className="h-full w-full bg-[linear-gradient(rgba(0,255,65,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,65,0.1)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
        </div>
        <div className="relative bg-[#0d0d0d] p-6 md:p-8 rounded-lg border border-[#00ff41]/20 w-full max-w-md shadow-[0_0_50px_rgba(0,255,65,0.05)]">
          <div className="flex items-center gap-2 text-[#00ff41] text-[10px] uppercase tracking-[0.4em] mb-8 font-bold">
            <ShieldCheck size={14} /> Security_Gate
          </div>
          <h1 className="text-2xl md:text-3xl font-black mb-8 text-white uppercase tracking-tighter text-center">Admin <span className="text-[#00ff41]">Access</span></h1>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] text-[#00ff41]/40 uppercase tracking-widest font-bold">Encrypted_Key</label>
              <input 
                type="password" 
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black border border-[#00ff41]/20 rounded-md p-4 text-[#00ff41] font-mono focus:border-[#00ff41] outline-none transition-colors"
              />
            </div>
            <button className="w-full bg-[#00ff41] text-black font-black py-4 rounded-md hover:bg-[#00cc33] transition-all transform active:scale-95 uppercase tracking-widest">
              Establish_Session
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#00ff41] font-mono selection:bg-[#00ff41] selection:text-[#0a0a0a] flex flex-col md:flex-row relative">
      {/* Sidebar Navigation - Fixed on Desktop, Bottom Navbar on Mobile */}
      <aside className={`fixed bottom-0 left-0 w-full h-16 md:h-screen md:w-64 bg-[#0d0d0d] border-t md:border-t-0 md:border-r border-[#00ff41]/10 z-40 flex flex-row md:flex-col transition-all duration-300 ${
        !sidebarOpen && 'md:-translate-x-full'
      }`}>
        <div className="p-4 md:p-6 border-r md:border-r-0 md:border-b border-[#00ff41]/10 hidden md:flex items-center justify-between">
          <span className="font-bold tracking-[0.2em] text-xl text-white">AeroX<span className="text-[#00ff41]">_ADM</span></span>
          <button
            onClick={() => setSidebarOpen(false)}
            className="hidden md:flex p-2 hover:bg-white/5 rounded transition-colors"
            title="Close sidebar"
          >
            <X size={18} className="text-white/40" />
          </button>
        </div>
        
        <nav className="flex-1 flex flex-row md:flex-col justify-around md:justify-start md:py-8 space-y-0 md:space-y-2 px-2 md:px-3">
          {[
            { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
            { id: 'products', icon: ShoppingBag, label: 'Store_Ops' },
            { id: 'codes', icon: Code, label: 'Source_Codes' },
            { id: 'settings', icon: Settings, label: 'Config' }
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex-1 md:flex-none flex items-center justify-center md:justify-start gap-3 p-3 md:p-4 rounded-md transition-all ${
                activeTab === item.id 
                  ? 'bg-[#00ff41]/10 text-[#00ff41] border border-[#00ff41]/20' 
                  : 'text-white/40 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon size={20} className="shrink-0" />
              <span className="hidden md:inline uppercase text-[11px] font-bold tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-2 md:p-4 border-l md:border-l-0 md:border-t border-[#00ff41]/10 flex flex-row md:flex-col gap-2">
          <button 
            onClick={() => navigate('/')}
            className="flex-1 md:flex-none flex items-center justify-center md:justify-start gap-3 p-3 md:p-4 text-white/40 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} className="shrink-0" />
            <span className="hidden md:inline uppercase text-[10px] font-bold">Exit_Root</span>
          </button>
          <button 
            onClick={() => setIsLoggedIn(false)}
            className="flex-1 md:flex-none flex items-center justify-center md:justify-start gap-3 p-3 md:p-4 text-red-500/60 hover:text-red-500 transition-colors"
          >
            <LogOut size={20} className="shrink-0" />
            <span className="hidden md:inline uppercase text-[10px] font-bold">Terminate</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className={`flex-1 pb-20 md:pb-12 transition-all duration-300 ${sidebarOpen ? 'md:pl-64' : 'md:pl-0'} p-4 md:p-8 lg:p-12 min-h-screen w-full max-w-full overflow-x-hidden`}>
        {/* Toggle Button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="fixed top-8 right-8 z-50 hidden md:flex items-center justify-center w-12 h-12 bg-[#00ff41]/10 hover:bg-[#00ff41]/20 border border-[#00ff41]/30 text-[#00ff41] rounded-md transition-all duration-200 hover:border-[#00ff41]/50"
          title={sidebarOpen ? 'Close sidebar' : 'Open sidebar'}
        >
          {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        <div className="max-w-6xl mx-auto w-full">
          {activeTab === 'dashboard' && (
            <div className="space-y-8 md:space-y-12">
              <div className="space-y-2 md:space-y-4">
                <div className="text-[10px] text-[#00ff41]/40 uppercase tracking-[0.5em] font-bold">Operational_Status</div>
                <h1 className="text-3xl md:text-5xl lg:text-6xl font-black text-white uppercase tracking-tighter">Command <span className="text-[#00ff41]">Center</span></h1>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 w-full">
                {[
                  { icon: Database, label: 'Registry_Size', value: `${products.length} Units` },
                  { icon: Activity, label: 'Sync_Latency', value: '14ms' },
                  { icon: ShieldCheck, label: 'Session_Status', value: 'Authorized' }
                ].map((stat, i) => (
                  <div key={i} className="p-5 md:p-6 border border-[#00ff41]/10 bg-white/[0.02] rounded-lg">
                    <stat.icon size={20} className="text-[#00ff41]/40 mb-3 md:mb-4" />
                    <div className="text-[10px] text-white/30 uppercase tracking-widest mb-1">{stat.label}</div>
                    <div className="text-xl md:text-2xl font-black text-white">{stat.value}</div>
                  </div>
                ))}
              </div>

              <div className="p-5 md:p-8 border border-[#00ff41]/10 bg-[#0d0d0d] rounded-lg overflow-hidden">
                <div className="flex items-center justify-between mb-6 border-b border-[#00ff41]/10 pb-4">
                  <div className="text-[10px] text-white/40 uppercase tracking-widest flex items-center gap-2">
                    <Activity size={12} /> Live_Log_Feed
                  </div>
                  <div className="text-[10px] text-[#00ff41]">v2.0.26_ACTIVE</div>
                </div>
                <div className="space-y-3 md:space-y-4 text-[10px] md:text-xs font-mono opacity-60 overflow-hidden">
                  <div className="flex gap-3 md:gap-4">
                    <span className="text-[#00ff41] shrink-0">[OK]</span>
                    <span className="break-all">Admin_Session established at {new Date().toLocaleTimeString()}</span>
                  </div>
                  <div className="flex gap-3 md:gap-4">
                    <span className="text-blue-400 shrink-0">[INFO]</span>
                    <span className="break-all">Product_Registry synchronization complete. Found {products.length} entries.</span>
                  </div>
                  <div className="flex gap-3 md:gap-4">
                    <span className="text-amber-400 shrink-0">[WARN]</span>
                    <span className="break-all">Global node latency within acceptable parameters (14ms).</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-8 md:space-y-12">
              <div className="space-y-2 md:space-y-4">
                <div className="text-[10px] text-[#00ff41]/40 uppercase tracking-[0.5em] font-bold">Store_Operations</div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-black text-white uppercase tracking-tighter">Registry <span className="text-[#00ff41]">Management</span></h1>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 md:gap-10 lg:gap-12 items-start">
                {/* Form Column */}
                <div className="xl:col-span-5 2xl:col-span-4 w-full">
                  <div className="bg-[#0d0d0d] p-6 md:p-8 border border-[#00ff41]/20 rounded-lg shadow-2xl w-full">
                    <div className="flex items-center gap-2 text-[#00ff41] text-[10px] uppercase tracking-widest mb-8 font-bold">
                      <Plus size={14} className={editingId !== null ? 'rotate-45' : ''} /> 
                      {editingId !== null ? 'Modify_Protocol' : 'New_Protocol'}
                    </div>
                    <form onSubmit={addProduct} className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Descriptor_Title</label>
                        <input 
                          placeholder="EX: Advanced Bot Core"
                          value={newProduct.title}
                          onChange={e => setNewProduct({...newProduct, title: e.target.value})}
                          className="w-full bg-black border border-[#00ff41]/20 rounded-md p-3 text-white text-sm focus:border-[#00ff41] outline-none transition-colors"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Kernel_Description</label>
                        <textarea 
                          placeholder="System specifications..."
                          value={newProduct.description}
                          onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                          className="w-full bg-black border border-[#00ff41]/20 rounded-md p-3 text-white text-sm focus:border-[#00ff41] outline-none h-32 resize-none transition-colors"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Credit_Value</label>
                        <input 
                          placeholder="$99.00"
                          value={newProduct.price}
                          onChange={e => setNewProduct({...newProduct, price: e.target.value})}
                          className="w-full bg-black border border-[#00ff41]/20 rounded-md p-3 text-white text-sm focus:border-[#00ff41] outline-none transition-colors"
                          required
                        />
                      </div>
                      <div className="space-y-4">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Visual_Buffers (URLs)</label>
                        <div className="flex gap-2">
                          <input 
                            placeholder="https://..."
                            value={imageUrl}
                            onChange={e => setImageUrl(e.target.value)}
                            className="flex-1 min-w-0 bg-black border border-[#00ff41]/20 rounded-md p-3 text-white text-xs focus:border-[#00ff41] outline-none transition-colors"
                          />
                          <button 
                            type="button"
                            onClick={handleAddImageUrl}
                            className="px-4 bg-[#00ff41] text-black font-black uppercase text-[10px] rounded-md shrink-0"
                          >
                            Push
                          </button>
                        </div>
                        <div className="flex flex-wrap gap-2 pt-1">
                          {newProduct.images.map((img, index) => (
                            <div key={index} className="relative w-12 h-12 rounded border border-[#00ff41]/20 overflow-hidden group/img">
                              <img src={img} className="w-full h-full object-cover" alt="" />
                              <button 
                                type="button"
                                onClick={() => setNewProduct({
                                  ...newProduct, 
                                  images: newProduct.images.filter((_, i) => i !== index)
                                })}
                                className="absolute inset-0 bg-black/80 flex items-center justify-center opacity-0 group-hover/img:opacity-100 transition-opacity"
                              >
                                <Trash2 size={12} className="text-red-500" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-3 pt-2">
                        <button className="flex-1 bg-[#00ff41] text-black font-black py-4 rounded-md uppercase tracking-widest text-[10px] md:text-xs active:scale-95 transition-transform shadow-[0_0_15px_rgba(0,255,65,0.2)]">
                          {editingId !== null ? 'Apply_Changes' : 'Commit_Protocol'}
                        </button>
                        {editingId !== null && (
                          <button 
                            type="button"
                            onClick={() => {
                              setEditingId(null);
                              setNewProduct({ title: '', description: '', price: '', images: [] });
                            }}
                            className="py-4 px-4 border border-white/20 text-white/40 hover:text-white rounded-md text-[10px] uppercase transition-colors"
                          >
                            Abort
                          </button>
                        )}
                      </div>
                    </form>
                  </div>
                </div>

                {/* List Column */}
                <div className="xl:col-span-7 2xl:col-span-8 space-y-4 w-full overflow-hidden">
                  <div className="text-[10px] text-white/40 uppercase tracking-widest font-bold mb-4">Registry_Feed ({products.length})</div>
                  {products.length === 0 ? (
                    <div className="p-10 border-2 border-dashed border-[#00ff41]/10 rounded-lg text-center bg-white/[0.01]">
                      <div className="text-white/20 text-xs uppercase tracking-widest font-bold leading-relaxed">No operational modules found in local registry.</div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4 w-full">
                      {products.map((p: any) => (
                        <div key={p.id} className="bg-[#0d0d0d] p-4 md:p-6 border border-[#00ff41]/10 rounded-lg flex flex-col sm:flex-row items-start sm:items-center gap-4 md:gap-6 group hover:border-[#00ff41]/30 transition-all w-full overflow-hidden">
                          <div className="flex items-center gap-4 w-full sm:w-auto overflow-hidden">
                            {p.images && p.images.length > 0 ? (
                              <img src={p.images[0]} className="w-16 h-16 md:w-20 md:h-20 rounded border border-white/5 object-cover grayscale group-hover:grayscale-0 transition-all shrink-0" alt="" />
                            ) : (
                              <div className="w-16 h-16 md:w-20 md:h-20 rounded bg-black border border-white/5 flex items-center justify-center text-[8px] text-white/10 uppercase font-black shrink-0">NO_IMG</div>
                            )}
                            <div className="sm:hidden flex-1 min-w-0">
                              <h3 className="font-black text-base md:text-lg text-white uppercase truncate tracking-tight">{p.title}</h3>
                              <div className="text-[10px] text-[#00ff41] font-bold tracking-widest">{p.price}</div>
                            </div>
                          </div>
                          <div className="hidden sm:block flex-1 min-w-0 space-y-1">
                            <h3 className="font-black text-lg md:text-xl text-white uppercase truncate tracking-tight">{p.title}</h3>
                            <div className="text-[10px] text-[#00ff41] font-bold tracking-widest">{p.price}</div>
                          </div>
                          <div className="flex gap-3 w-full sm:w-auto justify-end shrink-0">
                            <button 
                              onClick={() => startEdit(p)}
                              className="flex-1 sm:flex-none p-3 bg-white/5 border border-white/10 text-white/40 hover:text-[#00ff41] hover:border-[#00ff41]/30 transition-all rounded flex items-center justify-center"
                            >
                              <Settings size={18} />
                            </button>
                            <button 
                              onClick={() => removeProduct(p.id)}
                              className="flex-1 sm:flex-none p-3 bg-white/5 border border-white/10 text-white/40 hover:text-red-500 hover:border-red-500/30 transition-all rounded flex items-center justify-center"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'codes' && (
            <div className="space-y-8 md:space-y-12">
              <div className="space-y-2 md:space-y-4">
                <div className="text-[10px] text-[#00ff41]/40 uppercase tracking-[0.5em] font-bold">Source_Management</div>
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-black text-white uppercase tracking-tighter">Code <span className="text-[#00ff41]">Library</span></h1>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 md:gap-10 lg:gap-12 items-start">
                {/* Form Column */}
                <div className="xl:col-span-5 2xl:col-span-4 w-full">
                  <div className="bg-[#0d0d0d] p-6 md:p-8 border border-[#00ff41]/20 rounded-lg shadow-2xl w-full">
                    <div className="flex items-center gap-2 text-[#00ff41] text-[10px] uppercase tracking-widest mb-8 font-bold">
                      <Plus size={14} className={editingCodeId !== null ? 'rotate-45' : ''} /> 
                      {editingCodeId !== null ? 'Modify_Source' : 'New_Source'}
                    </div>
                    <form onSubmit={addCode} className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Select_Video</label>
                        <div className="space-y-3">
                          <div className="flex gap-2">
                            <input 
                              placeholder="Search videos..."
                              value={videoSearchQuery}
                              onChange={e => setVideoSearchQuery(e.target.value)}
                              className="flex-1 bg-black border border-[#00ff41]/20 rounded-md p-3 text-white text-sm focus:border-[#00ff41] outline-none transition-colors"
                            />
                            <button 
                              type="button"
                              onClick={fetchYoutubeVideos}
                              className="px-4 bg-[#00ff41]/10 text-[#00ff41] border border-[#00ff41]/30 hover:bg-[#00ff41]/20 rounded-md text-[10px] font-bold uppercase transition-all"
                            >
                              Sync
                            </button>
                          </div>
                          
                          <div className="max-h-48 overflow-y-auto border border-[#00ff41]/10 rounded-md bg-black/40 p-2 space-y-1 custom-scrollbar">
                            {loadingVideos ? (
                              <div className="py-4 text-center text-[10px] text-[#00ff41]/40 animate-pulse">Fetching_Video_Stream...</div>
                            ) : filteredVideos.length === 0 ? (
                              <div className="py-4 text-center text-[10px] text-white/20">No_Videos_Found</div>
                            ) : (
                              filteredVideos.map((video) => (
                                <button
                                  key={video.videoId}
                                  type="button"
                                  onClick={() => setNewCode({
                                    ...newCode,
                                    videoTitle: video.videoTitle,
                                    videoId: video.videoId,
                                    thumbnail: video.thumbnail,
                                    publishedAt: video.publishedAt
                                  })}
                                  className={`w-full flex items-center gap-3 p-2 rounded text-left transition-all ${
                                    newCode.videoId === video.videoId 
                                      ? 'bg-[#00ff41]/20 border border-[#00ff41]/40' 
                                      : 'hover:bg-white/5 border border-transparent'
                                  }`}
                                >
                                  <img src={video.thumbnail} className="w-12 h-8 object-cover rounded shadow-sm" alt="" />
                                  <div className="flex-1 min-w-0">
                                    <div className="text-[10px] text-white font-bold truncate uppercase">{video.videoTitle}</div>
                                    <div className="text-[8px] text-[#00ff41]/40 font-mono">{video.videoId}</div>
                                  </div>
                                </button>
                              ))
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Selected_Metadata</label>
                        <div className="p-3 bg-black/40 border border-[#00ff41]/10 rounded-md space-y-2">
                          <div className="flex justify-between items-center text-[9px]">
                            <span className="text-white/40">Title:</span>
                            <span className="text-[#00ff41] truncate ml-2">{newCode.videoTitle || 'NONE'}</span>
                          </div>
                          <div className="flex justify-between items-center text-[9px]">
                            <span className="text-white/40">ID:</span>
                            <span className="text-[#00ff41] font-mono">{newCode.videoId || 'NONE'}</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-[10px] text-white/30 uppercase tracking-widest">Code_Link (GitHub)</label>
                        <input 
                          placeholder="https://github.com/..."
                          value={newCode.codeLink}
                          onChange={e => setNewCode({...newCode, codeLink: e.target.value})}
                          className="w-full bg-black border border-[#00ff41]/20 rounded-md p-3 text-white text-sm focus:border-[#00ff41] outline-none transition-colors"
                          required
                        />
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3 pt-2">
                        <button 
                          disabled={!newCode.videoId}
                          className={`flex-1 font-black py-4 rounded-md uppercase tracking-widest text-[10px] md:text-xs active:scale-95 transition-transform shadow-[0_0_15px_rgba(0,255,65,0.2)] ${
                            !newCode.videoId 
                              ? 'bg-white/5 text-white/20 cursor-not-allowed' 
                              : 'bg-[#00ff41] text-black'
                          }`}
                        >
                          {editingCodeId !== null ? 'Apply_Changes' : 'Commit_Source'}
                        </button>
                        {editingCodeId !== null && (
                          <button 
                            type="button"
                            onClick={() => {
                              setEditingCodeId(null);
                              setNewCode({ videoTitle: '', videoId: '', thumbnail: '', codeLink: '', publishedAt: '' });
                            }}
                            className="py-4 px-4 border border-white/20 text-white/40 hover:text-white rounded-md text-[10px] uppercase transition-colors"
                          >
                            Abort
                          </button>
                        )}
                      </div>
                    </form>
                  </div>
                </div>

                {/* List Column */}
                <div className="xl:col-span-7 2xl:col-span-8 space-y-4 w-full overflow-hidden">
                  <div className="text-[10px] text-white/40 uppercase tracking-widest font-bold mb-4">Code_Registry ({codes.length})</div>
                  {codes.length === 0 ? (
                    <div className="p-10 border-2 border-dashed border-[#00ff41]/10 rounded-lg text-center bg-white/[0.01]">
                      <div className="text-white/20 text-xs uppercase tracking-widest font-bold leading-relaxed">No code sources found in registry.</div>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4 w-full">
                      {codes.map((c: any) => (
                        <div key={c.id} className="bg-[#0d0d0d] p-4 md:p-6 border border-[#00ff41]/10 rounded-lg flex flex-col sm:flex-row items-start sm:items-center gap-4 md:gap-6 group hover:border-[#00ff41]/30 transition-all w-full overflow-hidden">
                          <div className="flex items-center gap-4 w-full sm:w-auto overflow-hidden">
                            <div className="flex-1 min-w-0">
                              <h3 className="font-black text-base md:text-lg text-white uppercase truncate tracking-tight">{c.videoTitle}</h3>
                              <div className="text-[10px] text-[#00ff41] font-bold tracking-widest mt-1">{c.videoId}</div>
                            </div>
                          </div>
                          <div className="hidden sm:block flex-1 min-w-0 space-y-1">
                            <h3 className="font-black text-lg md:text-xl text-white uppercase truncate tracking-tight">{c.videoTitle}</h3>
                            <div className="text-[10px] text-[#00ff41] font-bold tracking-widest">{c.videoId}</div>
                          </div>
                          <div className="flex gap-3 w-full sm:w-auto justify-end shrink-0">
                            <button 
                              onClick={() => startEditCode(c)}
                              className="flex-1 sm:flex-none p-3 bg-white/5 border border-white/10 text-white/40 hover:text-[#00ff41] hover:border-[#00ff41]/30 transition-all rounded flex items-center justify-center"
                            >
                              <Settings size={18} />
                            </button>
                            <button 
                              onClick={() => removeCode(c.id)}
                              className="flex-1 sm:flex-none p-3 bg-white/5 border border-white/10 text-white/40 hover:text-red-500 hover:border-red-500/30 transition-all rounded flex items-center justify-center"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6 w-full px-4">
              <div className="p-6 bg-[#00ff41]/5 border border-[#00ff41]/10 rounded-full animate-pulse shadow-[0_0_30px_rgba(0,255,65,0.05)]">
                <Settings size={48} className="text-[#00ff41]/40" />
              </div>
              <div className="space-y-3">
                <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tighter">System_Configuration</h2>
                <p className="text-[#00ff41]/40 text-[10px] md:text-xs uppercase tracking-widest leading-relaxed max-w-xs mx-auto">Hardware interface locked by root protocol. Higher authorization required.</p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminPanel;