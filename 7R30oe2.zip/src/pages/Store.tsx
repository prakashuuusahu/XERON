import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronLeft, ChevronRight, Terminal, ExternalLink, Cpu, Database } from 'lucide-react';
import Navbar from '../sections/Navbar';
import Footer from '../sections/Footer';
import { productService } from '../lib/productService';

const ProductCard = ({ product, i }: { product: any, i: number }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const images = Array.isArray(product.images) && product.images.length > 0 
    ? product.images 
    : (product.image ? [product.image] : []);

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <>
      <div 
        onClick={() => setShowModal(true)}
        className="group relative bg-[#0d0d0d] border border-[#00d2ff]/10 hover:border-[#00d2ff]/40 transition-all duration-500 cursor-pointer flex flex-col h-full overflow-hidden rounded-xl"
      >
        <div className="absolute top-0 right-0 p-2 text-[8px] font-bold text-[#00d2ff]/20 tracking-widest z-10">
          NODE_0x0{i+1}
        </div>

        {images.length > 0 ? (
          <div className="relative aspect-video overflow-hidden bg-black/40 border-b border-[#00d2ff]/10">
            <img 
              src={images[currentImageIndex]} 
              alt={product.title} 
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105"
            />
            {images.length > 1 && (
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1 z-10">
                {images.map((_: any, idx: number) => (
                  <div 
                    key={idx} 
                    className={`w-1 h-1 ${idx === currentImageIndex ? 'bg-[#00d2ff]' : 'bg-white/20'}`}
                  />
                ))}
              </div>
            )}
            <div className="absolute top-4 left-4 bg-black/80 border border-[#00d2ff]/30 text-[#00d2ff] font-bold px-2 py-1 text-[10px] z-10 tracking-tighter">
              {product.price}
            </div>
          </div>
        ) : (
          <div className="aspect-video bg-black/40 border-b border-[#00d2ff]/10 flex items-center justify-center">
            <Database size={32} className="text-[#00d2ff]/10" />
          </div>
        )}

        <div className="p-6 flex-1 flex flex-col space-y-4">
          <div className="space-y-1">
            <h3 className="text-xl font-black text-white uppercase tracking-tighter group-hover:text-[#00d2ff] transition-colors truncate">{product.title}</h3>
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-[#00d2ff]/10"></div>
              <span className="text-[8px] text-[#00d2ff]/40 font-bold uppercase tracking-widest">Registry_Module</span>
            </div>
          </div>
          
          <p className="text-white/50 text-xs leading-relaxed line-clamp-3 font-mono h-12">
            {product.description}
          </p>

          <div className="mt-auto pt-4 flex items-center justify-between">
            <div className="text-[10px] text-white/20 uppercase tracking-widest font-bold group-hover:text-[#00d2ff]/40 transition-colors">
              Initialize_Acquisition
            </div>
            <ExternalLink size={14} className="text-[#00d2ff]/20 group-hover:text-[#00d2ff] transition-colors" />
          </div>
        </div>

        {/* Hover accent */}
        <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#00d2ff] transition-all duration-500 group-hover:w-full"></div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/95 backdrop-blur-sm animate-in fade-in duration-300">
          <div 
            className="bg-[#0d0d0d] w-full max-w-5xl max-h-[90vh] border border-[#00d2ff]/30 flex flex-col md:flex-row shadow-[0_0_50px_rgba(0,210,255,0.1)] overflow-hidden relative rounded-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => setShowModal(false)}
              className="absolute top-4 left-4 z-20 flex items-center gap-2 bg-black border border-[#00d2ff]/30 text-[#00d2ff] px-4 py-2 text-[10px] font-bold uppercase tracking-widest hover:bg-[#00d2ff]/10 transition-colors"
            >
              <ArrowLeft size={12} /> ABORT_VIEW
            </button>

            <div className="md:w-3/5 h-64 md:h-auto bg-black relative overflow-hidden flex items-center justify-center shrink-0">
              {images.length > 0 ? (
                <>
                  <img src={images[currentImageIndex]} className="w-full h-full object-contain" alt="" />
                  {images.length > 1 && (
                    <>
                      <button onClick={prevImage} className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 border border-[#00d2ff]/20 hover:border-[#00d2ff]/60 p-2 text-[#00d2ff] transition-colors"><ChevronLeft /></button>
                      <button onClick={nextImage} className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 border border-[#00d2ff]/20 hover:border-[#00d2ff]/60 p-2 text-[#00d2ff] transition-colors"><ChevronRight /></button>
                    </>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center gap-4 text-[#00d2ff]/20">
                  <Database size={64} />
                  <span className="text-xs uppercase tracking-[0.5em]">No_Visual_Data</span>
                </div>
              )}
            </div>

            <div className="flex-1 p-6 md:p-12 overflow-y-auto flex flex-col min-h-0">
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-2 text-[#00d2ff]/40 text-[10px] uppercase tracking-[0.4em] font-bold pt-8 md:pt-0">
                  <Cpu size={14} /> registry_entry.v2
                </div>
                <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter leading-tight break-words">{product.title}</h2>
                <div className="text-2xl md:text-3xl font-black text-[#00d2ff] tracking-tighter">{product.price}</div>
              </div>

              <div className="h-px bg-[#00d2ff]/10 w-full mb-8"></div>

              <div className="prose prose-invert max-w-none mb-12">
                <p className="text-white/70 leading-relaxed font-mono text-sm whitespace-pre-wrap">{product.description}</p>
              </div>

              <div className="mt-auto pt-8 border-t border-[#00d2ff]/10 shrink-0">
                <a 
                  href="https://discord.gg/8wfT8SfB5Z"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center bg-[#00d2ff] text-black font-black py-4 md:py-5 uppercase tracking-[0.2em] hover:bg-[#00b8e6] transition-all transform active:scale-95 shadow-[0_0_20px_rgba(0,210,255,0.2)] text-xs md:text-base rounded-xl"
                >
                  EXECUTE_PURCHASE_PROTOCOL
                </a>
                <p className="text-[9px] text-white/30 text-center mt-4 uppercase tracking-widest font-bold">Secure endpoint established via Discord relay</p>
              </div>
            </div>
          </div>
          <div className="absolute inset-0 -z-10" onClick={() => setShowModal(false)} />
        </div>
      )}
    </>
  );
};

const Store = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await productService.getAllProducts();
        setProducts(data || []);
      } catch (error) {
        console.error('Failed to fetch products:', error);
        setProducts([]);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-mono selection:bg-[#00d2ff]/30 overflow-x-hidden">
      <Navbar />
      
      {/* Matrix Background Effect */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#00d2ff_0%,transparent_70%)] opacity-20"></div>
        <div className="h-full w-full bg-[linear-gradient(rgba(0,210,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,210,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      </div>

      <main className="relative z-10 pt-32 pb-24 px-4 md:px-8 lg:px-12 max-w-7xl mx-auto">
        <div className="mb-16 space-y-6">
          <button 
            onClick={() => navigate('/')}
            className="group flex items-center gap-2 text-white/40 hover:text-[#00d2ff] transition-colors text-[10px] font-bold uppercase tracking-widest"
          >
            <ArrowLeft size={12} className="group-hover:-translate-x-1 transition-transform" />
            EXIT_TO_ROOT
          </button>
          
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#00d2ff]/40 text-xs uppercase tracking-[0.5em] font-bold">
              <Terminal size={14} /> asset_registry.sh
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-white uppercase tracking-tighter leading-none">AeroX <span className="text-[#00d2ff]">Store</span></h1>
            <p className="text-white/60 text-base md:text-xl max-w-2xl leading-relaxed border-l-2 border-[#00d2ff]/30 pl-6">
              Premium resources and production-ready kernels for professional development projects.
            </p>
          </div>
        </div>
        
        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-6">
            <div className="relative">
              <div className="w-16 h-16 border-2 border-white/10 rounded-full"></div>
              <div className="absolute inset-0 w-16 h-16 border-t-2 border-[#00d2ff] rounded-full animate-spin"></div>
            </div>
            <div className="text-[10px] text-[#00d2ff] font-bold uppercase tracking-[0.5em] animate-pulse">Syncing_Registry...</div>
          </div>
        ) : products.length === 0 ? (
          <div className="py-32 border border-white/10 bg-white/[0.02] text-center rounded-lg">
            <Database size={48} className="mx-auto text-white/10 mb-6" />
            <div className="text-sm uppercase tracking-widest text-white/40">No operational modules found in remote registry.</div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {products.map((product, idx) => (
              <ProductCard key={product.id} product={product} i={idx} />
            ))}
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Store;
