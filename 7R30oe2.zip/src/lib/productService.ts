// @ts-ignore
import { config } from '../config';

export const productService = {
  config,
  async saveData(fileName: string, data: any) {
    const { owner, repo, token } = config.github;
    const path = `data/${fileName}`;
    
    if (!owner || !repo || !token || owner === 'YOUR_GITHUB_USERNAME') {
      throw new Error('GitHub configuration missing. Please fill in config.js');
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    
    try {
      const getFileResponse = await fetch(url, {
        headers: {
          'Authorization': `token ${token}`
        },
        cache: 'no-store'
      });

      let sha = '';

      if (getFileResponse.ok) {
        const fileData = await getFileResponse.json();
        sha = fileData.sha;
      }

      const jsonString = JSON.stringify(data, null, 2);
      const bytes = new TextEncoder().encode(jsonString);
      let binaryString = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binaryString += String.fromCharCode(bytes[i]);
      }
      const updatedContent = btoa(binaryString);

      const updateResponse = await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Update ${fileName}`,
          content: updatedContent,
          sha: sha || undefined
        })
      });

      if (!updateResponse.ok) {
        const errorData = await updateResponse.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to update GitHub: ${updateResponse.status}`);
      }

      return data;
    } catch (error: any) {
      console.error('Detailed error saving to GitHub:', error);
      throw error;
    }
  },

  async getAllCodes() {
    const { owner, repo, token } = config.github;
    const path = 'data/codes.json';
    
    if (!owner || !repo || !token || owner === 'YOUR_GITHUB_USERNAME') {
      return [];
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    
    try {
      const response = await fetch(url, {
        headers: {
          'Authorization': `token ${token}`,
          'Accept': 'application/vnd.github.v3.raw'
        },
        cache: 'no-store'
      });
      
      if (!response.ok) throw new Error('Failed to fetch codes from GitHub');
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Error fetching codes from GitHub:', error);
      return [];
    }
  },

  async getAllProducts() {
    const { owner, repo, path, token } = config.github;
    
    if (!owner || !repo || !token || owner === 'YOUR_GITHUB_USERNAME') {
      return [];
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    
    try {
      const response = await fetch(url, {
        headers: {
          'Authorization': `token ${token}`,
          'Accept': 'application/vnd.github.v3.raw'
        },
        cache: 'no-store'
      });
      
      if (!response.ok) throw new Error('Failed to fetch from GitHub');
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Error fetching products from GitHub:', error);
      return [];
    }
  },

  async saveProduct(product: any) {
    const { owner, repo, path, token } = config.github;
    
    if (!owner || !repo || !token || owner === 'YOUR_GITHUB_USERNAME') {
      throw new Error('GitHub configuration missing. Please fill in config.js');
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    
    try {
      // 1. Get current file (to get SHA)
      const getFileResponse = await fetch(url, {
        headers: {
          'Authorization': `token ${token}`
        },
        cache: 'no-store'
      });

      let sha = '';
      let currentProducts: any[] = [];

      if (getFileResponse.ok) {
        const fileData = await getFileResponse.json();
        sha = fileData.sha;
        try {
          // Robust base64 decoding for Unicode
          const binaryString = atob(fileData.content.replace(/\n/g, ''));
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          const content = new TextDecoder().decode(bytes);
          currentProducts = JSON.parse(content);
        } catch (e) {
          console.error('Error parsing GitHub content:', e);
          currentProducts = [];
        }
      } else if (getFileResponse.status !== 404) {
        const errorData = await getFileResponse.json().catch(() => ({}));
        throw new Error(errorData.message || `GitHub error: ${getFileResponse.status}`);
      }

      // 2. Update/Add product
      const existingIndex = currentProducts.findIndex(p => String(p.id) === String(product.id));
      if (existingIndex > -1) {
        currentProducts[existingIndex] = { ...currentProducts[existingIndex], ...product };
      } else {
        currentProducts.push(product);
      }

      // 3. Push back to GitHub
      const jsonString = JSON.stringify(currentProducts, null, 2);
      const bytes = new TextEncoder().encode(jsonString);
      let binaryString = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binaryString += String.fromCharCode(bytes[i]);
      }
      const updatedContent = btoa(binaryString);

      const updateResponse = await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Update product: ${product.title}`,
          content: updatedContent,
          sha: sha || undefined
        })
      });

      if (!updateResponse.ok) {
        const errorData = await updateResponse.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to update GitHub: ${updateResponse.status}`);
      }

      return currentProducts;
    } catch (error: any) {
      console.error('Detailed error saving to GitHub:', error);
      throw error;
    }
  },

  async deleteProduct(id: string) {
    const { owner, repo, path, token } = config.github;
    
    if (!owner || !repo || !token || owner === 'YOUR_GITHUB_USERNAME') {
      throw new Error('GitHub configuration missing');
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;
    
    try {
      const getFileResponse = await fetch(url, {
        headers: { 'Authorization': `token ${token}` },
        cache: 'no-store'
      });

      if (!getFileResponse.ok) {
        if (getFileResponse.status === 404) return [];
        throw new Error(`GitHub error: ${getFileResponse.status}`);
      }
      
      const fileData = await getFileResponse.json();
      
      const binaryString = atob(fileData.content.replace(/\n/g, ''));
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const content = new TextDecoder().decode(bytes);
      const currentProducts = JSON.parse(content);
      
      const filteredProducts = currentProducts.filter((p: any) => String(p.id) !== String(id));

      const jsonString = JSON.stringify(filteredProducts, null, 2);
      const encoderBytes = new TextEncoder().encode(jsonString);
      let updatedBinaryString = '';
      for (let i = 0; i < encoderBytes.byteLength; i++) {
        updatedBinaryString += String.fromCharCode(encoderBytes[i]);
      }
      const updatedContent = btoa(updatedBinaryString);

      const updateResponse = await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: `Delete product: ${id}`,
          content: updatedContent,
          sha: fileData.sha
        })
      });

      if (!updateResponse.ok) {
        const errorData = await updateResponse.json().catch(() => ({}));
        throw new Error(errorData.message || `Failed to delete from GitHub: ${updateResponse.status}`);
      }
      return filteredProducts;
    } catch (error: any) {
      console.error('Detailed error deleting from GitHub:', error);
      throw error;
    }
  }
};
