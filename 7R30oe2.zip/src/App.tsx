import { Routes, Route } from 'react-router-dom';
import Hero from './sections/Hero';
import About from './sections/About';
import Feature from './sections/Feature';
import DiscordWidget from './sections/DiscordWidget';
import Footer from './sections/Footer';
import Navbar from './sections/Navbar';
import Invite from './components/Invite';
import YouTube from './pages/YouTube';
import Donate from './pages/Donate';
import ApiKeys from './pages/ApiKeys';
import Basics from './pages/Basics';
import Codes from './pages/Codes';
import Store from './pages/Store';
import AdminPanel from './pages/AdminPanel';

function MainPage() {
  return (
    <>
      <Navbar />
      <Hero />
      <About />
      <Feature />
      <DiscordWidget />
      <Footer />
    </>
  );
}

function App() {
  return (
    <main>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/invite" element={<Invite />} />
        <Route path="/youtube" element={<YouTube />} />
        <Route path="/donate" element={<Donate />} />
        <Route path="/api-keys" element={<ApiKeys />} />
        <Route path="/basics" element={<Basics />} />
        <Route path="/codes" element={<Codes />} />
        <Route path="/store" element={<Store />} />
        <Route path="/admin" element={<AdminPanel />} />
      </Routes>
    </main>
  );
}

export default App;