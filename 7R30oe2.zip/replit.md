# AeroX Development Community Platform

## Overview

AeroX Development is a community platform for developers and coders, built as a modern single-page application. The platform showcases the AeroX community, provides access to developer resources, and integrates with Discord and YouTube. It features a landing page with multiple sections (hero, about, features, FAQ), a YouTube video gallery, service status monitoring, comprehensive documentation with a unique black and lavender color scheme, and direct Discord bot invitation functionality.

## Recent Changes

**November 8, 2025**: Added comprehensive documentation page (`/docs`) with black and lavender theme featuring:
- Interactive sidebar navigation with smooth transitions
- Six main sections: Introduction, Discord Bots, Services, Community, Getting Started, and FAQ
- Custom lavender glow animations and purple accent colors
- Responsive design with custom scrollbar styling
- Detailed information about all AeroX Development services and bots

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework**: React 18.3 with TypeScript
- **Build Tool**: Vite 5.4 (fast development server and optimized production builds)
- **Routing**: React Router DOM v7 for client-side navigation
- **Styling**: Tailwind CSS with custom fonts (KG Corner of the Sky, Ubuntu)
- **UI Components**: Custom components with Lucide React icons

**Component Structure:**
The application follows a component-based architecture with clear separation:
- **Pages**: Top-level route components (MainPage, YouTube, Status, Docs)
- **Sections**: Reusable landing page sections (Hero, About, Feature, FAQ, Footer, Navbar)
- **Components**: Smaller reusable elements (Invite, icons)

**Routing Strategy:**
- Single-page application with five main routes:
  - `/` - Main landing page with all sections
  - `/invite` - Discord bot invitation redirect
  - `/youtube` - YouTube video gallery page
  - `/status` - Service status monitoring page
  - `/docs` - Comprehensive documentation page with black and lavender theme
- Client-side routing with Vercel rewrites configuration for SPA support

**Styling Approach:**
- Tailwind CSS utility-first styling
- Custom animated gradients using CSS keyframe animations
- Responsive design with mobile-first approach
- Custom font integration via `@font-face`

### State Management

**Pattern**: React Hooks (useState, useEffect) for local component state
- No global state management library used
- Component-level state for UI interactions (FAQ accordion, YouTube video loading)
- Simple and appropriate for the application's scale

### Performance Optimizations

- Vite's build optimization with code splitting
- Lucide React icons excluded from Vite's optimizeDeps to prevent bundling issues
- React Strict Mode enabled for development
- Lazy loading and image optimization through proper asset management

### Code Quality

**Linting and Type Safety:**
- ESLint with TypeScript support
- React Hooks linting rules
- React Refresh plugin for fast development feedback
- Strict TypeScript configuration with compiler checks

**Build Configuration:**
- TypeScript project references for better IDE performance
- Separate tsconfig files for app and node environments
- PostCSS with Tailwind and Autoprefixer

## External Dependencies

### Backend-as-a-Service

**Supabase** (@supabase/supabase-js v2.57.4)
- Purpose: Backend infrastructure and data storage
- Integration: Client-side SDK included but not actively used in visible code
- Usage: Likely for future features like user authentication, data persistence, or real-time features

### Third-Party APIs

**YouTube Data API v3**
- Purpose: Fetching channel videos for the YouTube gallery page
- Authentication: API key stored in environment variable (VITE_YOUTUBE_API_KEY)
- Features: Channel lookup by handle, playlist retrieval, video metadata
- Implementation: Direct REST API calls using native fetch

**YouTube Search Library** (youtube-search-without-api-key v2.0.7)
- Purpose: Alternative YouTube search functionality without API quota limits
- Status: Installed but not visibly used in current codebase

### External Services

**Discord**
- Bot invitation URL hardcoded in Invite component
- Client ID: 1151832497383030804
- Permissions: Administrator-level (1099511627775)
- Community link: discord.gg/8wfT8SfB5Z

**Social Media Integration**
- Domain: moonveil.xyz (primary) and moonveil.cyou (subdomain services)
- Open Graph and Twitter Card meta tags for social sharing
- Links to external documentation, status page, and store

### Asset Hosting

**Static Assets:**
- Favicons (multiple sizes for cross-platform support)
- Brand images (logo, character illustrations, background images)
- Custom fonts (KGCorneroftheSky.ttf)
- All assets served from public directory

### Deployment

**Vercel Platform**
- Configuration: SPA rewrites for client-side routing
- Build command: `vite build`
- Development server: Port 5000, host 0.0.0.0 for container compatibility

### Environment Variables

Required environment variables:
- `VITE_YOUTUBE_API_KEY` - YouTube Data API key for video fetching